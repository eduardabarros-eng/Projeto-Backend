# 🛒 API da Loja — Projeto Back-end

> **O que é?** Uma API REST para uma loja virtual. Ela cadastra **usuários**, **categorias** e **produtos** (com imagens, opções como tamanho/cor e várias categorias), protege a escrita com **login JWT** e traz **documentação interativa (Swagger)**.
>
> **Para quem?** Para quem está aprendendo back-end com Node.js, ou para um front-end (site/app) que precisa de uma loja pronta para consumir.

Construída com **Node.js + Express**, **MySQL + Sequelize** (com *migrations*), **JWT + bcrypt** e testada com **Jest + Supertest**.
Escopo seguido: <https://github.com/digitalcollegebr/projeto-backend> · Veja também [Sobre o projeto](docs/SOBRE-O-PROJETO.md) e o [Guia dos arquivos](docs/GUIA-DOS-ARQUIVOS.md).

---

## Sumário
1. [Tecnologias](#1-tecnologias)
2. [Pré-requisitos](#2-pré-requisitos)
3. [Como configurar e rodar](#3-como-configurar-e-rodar)
4. [Como usar a API (passo a passo)](#4-como-usar-a-api-passo-a-passo)
5. [Referência dos endpoints](#5-referência-dos-endpoints)
6. [Filtros da busca de produtos](#6-filtros-da-busca-de-produtos)
7. [Banco de dados](#7-banco-de-dados)
8. [Arquitetura e pastas](#8-arquitetura-e-pastas)
9. [Testes](#9-testes)
10. [Decisões de projeto](#10-decisões-de-projeto)
11. [Problemas comuns](#11-problemas-comuns)
12. [Checklist dos critérios de aprovação](#12-checklist-dos-critérios-de-aprovação)
13. [Como publicar no GitHub](#13-como-publicar-no-github)

---

## 1. Tecnologias

| Tecnologia | Para que serve |
|---|---|
| Node.js | Executar JavaScript no servidor |
| Express | Criar as rotas da API |
| Dotenv | Ler configurações e segredos do arquivo `.env` |
| Nodemon | Reiniciar o servidor ao salvar (desenvolvimento) |
| MySQL | Guardar os dados |
| Sequelize (+ sequelize-cli) | ORM e *migrations* (versionamento do banco) |
| bcrypt | Gerar o hash das senhas |
| JWT (jsonwebtoken) | Autenticação por token |
| Swagger UI | Documentação interativa da API |
| Jest + Supertest | Testes automatizados |

## 2. Pré-requisitos
- **Node.js 18 ou superior** (`node -v`)
- **MySQL 8** (ou MariaDB 10.5+) rodando na sua máquina
- **Git**

## 3. Como configurar e rodar

Escolha **uma** das duas formas. A **Opção A (Docker)** é a que funciona igual em qualquer máquina, sem instalar Node nem MySQL.

### Opção A — Docker (recomendada: Windows, macOS e Linux)

Precisa apenas do [Docker Desktop](https://www.docker.com/products/docker-desktop/) (ou Docker + Compose no Linux).

```bash
git clone <url-do-seu-repositorio>
cd projeto-backend
docker compose up --build
```

Pronto: o MySQL é criado, as tabelas são criadas (migrations) e a API sobe em **http://localhost:3000** (docs em `/api-docs`). Para parar: `Ctrl+C` e `docker compose down` (os dados ficam guardados; `docker compose down -v` apaga tudo).

Para mudar senha do banco, segredo do JWT ou porta, crie um arquivo `.env` ao lado do `docker-compose.yml` com `DB_PASS`, `DB_NAME`, `JWT_SECRET`, `PORT`... (todos têm padrão).

### Opção B — Sem Docker (Node + MySQL instalados)

```bash
# 1) Baixe o projeto e entre na pasta
git clone <url-do-seu-repositorio>
cd projeto-backend

# 2) Instale as dependências
npm install

# 3) Crie seu arquivo de configuração a partir do modelo
cp .env.example .env        # no Windows (cmd): copy .env.example .env
#    Abra o .env e preencha DB_USER, DB_PASS, DB_NAME e JWT_SECRET
#    (cada máquina tem sua senha de MySQL; é por isso que o .env não vai para o Git)

# 4) Crie o banco de dados (usa os dados do .env)
npm run db:create

# 5) Crie as tabelas (executa as migrations)
npm run db:migrate

# 6) Inicie a API
npm run dev      # desenvolvimento (reinicia ao salvar)
# ou
npm start        # produção
```

Pronto! Na sua máquina a API estará em **http://localhost:3000** e o Swagger em **http://localhost:3000/api-docs**.

> 🌐 **Em outro computador/servidor:** troque `localhost` pelo IP ou domínio da máquina onde a API roda (ex.: `http://192.168.0.10:3000`). Nada no código está preso a `localhost`: os links das imagens são montados com o endereço usado na requisição (ou com `BASE_URL`, se definido).

### Variáveis do `.env`
| Variável | O que é | Exemplo |
|---|---|---|
| `PORT` | Porta da API | `3000` |
| `BASE_URL` | *(opcional)* URL pública da API para os links das imagens. Vazio = usa o endereço pelo qual a API foi acessada (funciona em qualquer computador). Em produção, defina | `https://minha-api.com` |
| `DB_HOST` / `DB_PORT` | Endereço e porta do MySQL | `localhost` / `3306` |
| `DB_USER` / `DB_PASS` | Usuário e senha do MySQL | `root` / `sua_senha` |
| `DB_NAME` | Nome do banco | `projeto_backend` |
| `JWT_SECRET` | Segredo que assina os tokens (longo e aleatório) | `...` |
| `JWT_EXPIRES_IN` | Validade do token | `1h` |
| `UPLOAD_DIR` | Pasta das imagens enviadas | `uploads` |

### Scripts do `package.json`
| Comando | O que faz |
|---|---|
| `npm run dev` | Inicia com Nodemon |
| `npm start` | Inicia normalmente |
| `npm test` | Roda todos os testes |
| `npm run db:create` | Cria o banco |
| `npm run db:migrate` | Aplica as migrations |
| `npm run db:migrate:undo` | Desfaz a última migration |
| `npm run db:migrate:undo:all` | Desfaz todas |

## 4. Como usar a API (passo a passo)

Fluxo completo com `curl`:

```bash
# 0) Endereço da API: em outro computador, troque pelo IP ou domínio (ex.: http://192.168.0.10:3000)
API_URL="http://localhost:3000"

# 1) Cadastrar usuário (público)
curl -X POST $API_URL/v1/user \
  -H "Content-Type: application/json" \
  -d '{"firstname":"Maria","surname":"Silva","email":"maria@mail.com","password":"123@123","confirmPassword":"123@123"}'

# 2) Gerar o token (login)
curl -X POST $API_URL/v1/user/token \
  -H "Content-Type: application/json" \
  -d '{"email":"maria@mail.com","password":"123@123"}'
# => {"token":"eyJhbGciOi..."}

# 3) Guarde o token para as rotas protegidas (POST/PUT/DELETE)
TOKEN="cole-o-token-aqui"

# 4) Criar uma categoria
curl -X POST $API_URL/v1/category \
  -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" \
  -d '{"name":"Shoes","slug":"shoes","use_in_menu":true}'

# 5) Criar um produto (imagens em base64)
curl -X POST $API_URL/v1/product \
  -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" \
  -d '{
    "enabled": true, "name": "Tênis Runner", "slug": "tenis-runner", "stock": 10,
    "description": "Tênis leve", "price": 119.9, "price_with_discount": 99.9,
    "category_ids": [1],
    "images": [{"type":"image/png","content":"<base64 da imagem>"}],
    "options": [{"title":"Tamanho","shape":"square","radius":"4px","type":"text","values":["40","41","42"]}]
  }'

# 6) Buscar produtos com filtros (público)
curl -g "$API_URL/v1/product/search?match=Tênis&category_ids=1&price-range=50-150&limit=10&page=1"
```

> 💡 No Swagger (`/api-docs`) clique em **Authorize**, cole o token e teste tudo pelo navegador.

## 5. Referência dos endpoints

🔓 = público · 🔒 = exige `Authorization: Bearer <token>`

### Usuários
| Método | Rota | Acesso | Sucesso | Erros |
|---|---|---|---|---|
| POST | `/v1/user/token` | 🔓 | 200 `{token}` | 400 |
| POST | `/v1/user` | 🔓 | 201 | 400 |
| GET | `/v1/user/:id` | 🔓 | 200 | 404 |
| PUT | `/v1/user/:id` | 🔒 | 204 | 400, 401, 404 |
| DELETE | `/v1/user/:id` | 🔒 | 204 | 400, 401, 404 |

### Categorias
| Método | Rota | Acesso | Sucesso | Erros |
|---|---|---|---|---|
| GET | `/v1/category/search` | 🔓 | 200 | 400 |
| GET | `/v1/category/:id` | 🔓 | 200 | 404 |
| POST | `/v1/category` | 🔒 | 201 | 400, 401 |
| PUT | `/v1/category/:id` | 🔒 | 204 | 400, 401, 404 |
| DELETE | `/v1/category/:id` | 🔒 | 204 | 400, 401, 404 |

### Produtos
| Método | Rota | Acesso | Sucesso | Erros |
|---|---|---|---|---|
| GET | `/v1/product/search` | 🔓 | 200 | 400 |
| GET | `/v1/product/:id` | 🔓 | 200 | 404 |
| POST | `/v1/product` | 🔒 | 201 | 400, 401 |
| PUT | `/v1/product/:id` | 🔒 | 204 | 400, 401, 404 |
| DELETE | `/v1/product/:id` | 🔒 | 204 | 400, 401, 404 |

### Utilitários
- `GET /health` → `{"status":"ok"}`
- `GET /api-docs` → Swagger UI
- `GET /media/...` → imagens dos produtos

### Autenticação
| Situação | Resposta |
|---|---|
| Cabeçalho `Authorization` ausente ou fora do formato `Bearer <token>` | **400** |
| Token falso, adulterado ou expirado | **401** |

> O **400** das rotas 🔒 inclui o token ausente (Seção 05 do escopo).

### Formato dos erros
Todo erro devolve JSON com a mensagem:
```json
{ "message": "O campo \"name\" é obrigatório e deve ser um texto." }
```

### Atualizando imagens e opções (PUT `/v1/product/:id`)
Todos os campos são opcionais. Em `images` e `options`, cada item é interpretado assim:

| Item enviado | O que acontece |
|---|---|
| sem `id` | **cria** um novo |
| `{ "id": 2, "deleted": true }` | **remove** |
| `{ "id": 3, ...campos }` | **atualiza** (imagem com `content` em base64 troca o arquivo; `content` em URL mantém a atual) |

`category_ids`, quando enviado, **substitui** a lista de categorias do produto.

## 6. Filtros da busca de produtos

`GET /v1/product/search`

| Parâmetro | Descrição | Exemplo |
|---|---|---|
| `limit` | Itens por página (padrão 12; `-1` = todos) | `limit=30` |
| `page` | Página (padrão 1; ignorada com `limit=-1`) | `page=2` |
| `fields` | Campos retornados | `fields=name,images,price` |
| `match` | Termo no nome **ou** descrição | `match=Tênis` |
| `category_ids` | Produtos em **qualquer** dessas categorias | `category_ids=15,24` |
| `price-range` | Faixa de preço (inclusive) | `price-range=100-200` |
| `option[ID]` | Produtos cuja opção `ID` tenha algum dos valores | `option[45]=GG,PP` |

Os filtros podem ser **combinados** (todos precisam ser atendidos). A resposta traz `data`, `total` (para paginar), `limit` e `page`.

> Em `curl`, use `-g` quando a URL tiver colchetes (`option[45]`).

A busca de categorias (`/v1/category/search`) aceita `limit`, `page`, `fields` e `use_in_menu=true`.

## 7. Banco de dados

```
users                 categories             products
-----                 ----------             --------
id (PK)               id (PK)                id (PK)
firstname             name                   enabled
surname               slug                   name
email (único)         use_in_menu            slug
password (hash)       created_at             use_in_menu
created_at            updated_at             stock
updated_at                                   description
                                             price
                                             price_with_discount
                                             created_at / updated_at

product_images                product_options              product_categories
--------------                ---------------              ------------------
id (PK)                       id (PK)                      product_id (PK, FK)
product_id (FK → products)    product_id (FK → products)   category_id (PK, FK)
enabled                       title
path                          shape  (square | circle)
                              radius (inteiro)
                              type   (text | color)
                              values ("PP,M,GG")
```

- **Relacionamentos:** produto 1—N imagens; produto 1—N opções; produto N—N categorias (tabela `product_categories`, chave primária composta).
- **Integridade:** chaves estrangeiras com `ON DELETE CASCADE` — apagar um produto/categoria limpa as ligações automaticamente.
- **Índices:** `products(name)`, `products(price)`, as FKs de imagens/opções e `product_categories(category_id)`.
- **Migrations:** em `src/migrations` (uma por tabela), cada uma com `up` (cria) e `down` (desfaz).
- **Consultas eficientes:** a busca faz uma consulta só de ids (com `COUNT`) e depois carrega imagens, opções e categorias **em lote** — sem N+1.

## 8. Arquitetura e pastas

Padrão em camadas (inspirado em MVC): a **rota** chama o **controller**, que chama o **service** (regras de negócio), que usa os **models** (banco).

```
requisição → routes → middleware (auth) → controller → service → model → MySQL
                                                                   ↓
resposta   ← errorHandler (se der erro) ←──────────────────────────┘
```

```
project-root/
├── src/
│   ├── config/        # banco, JWT e upload de imagens
│   ├── controllers/   # recebem req/res e devolvem o status HTTP
│   ├── docs/          # especificação Swagger (OpenAPI)
│   ├── middleware/    # auth (JWT) e tratamento de erros
│   ├── migrations/    # criação das tabelas (versionadas)
│   ├── models/        # models Sequelize e relacionamentos
│   ├── routes/        # mapa URL → controller
│   ├── services/      # regras de negócio e validações
│   ├── utils/         # AppError, validadores, paginação
│   ├── app.js         # monta o Express (sem iniciar)
│   └── server.js      # conecta no banco e inicia o servidor
├── tests/             # testes Jest + Supertest
├── uploads/           # imagens enviadas (ignorada pelo Git)
├── docs/              # documentação em texto
├── .env.example       # modelo das variáveis de ambiente
├── Dockerfile         # imagem da API (roda em qualquer máquina)
├── docker-compose.yml # sobe MySQL + API com um comando
└── package.json
```

Princípio SOLID aplicado: cada arquivo tem **uma responsabilidade** (controller só traduz HTTP; service só tem regra de negócio; model só descreve dados).

## 9. Testes

```bash
npm test
```

- Cobrem usuários, JWT, CRUD de categorias, CRUD de produtos, imagens, opções, filtros, paginação, transações e erros (400/401/404).
- Rodam em **SQLite em memória** (não precisam do MySQL nem mexem nos seus dados); as imagens de teste vão para uma pasta temporária.

## 10. Decisões de projeto

- **Token ausente → 400; token inválido/expirado → 401.** Segue a Seção 05 do escopo (400 sem o cabeçalho) e mantém 401 para token incorreto. Para ajustar, edite `src/middleware/auth.js`.
- **Rotas públicas:** cadastro, login e todos os `GET`, como no escopo. `PUT`/`DELETE` de usuário exigem token (qualquer usuário autenticado, pois o escopo não define "donos" dos registros).
- **Login com dados errados → 400**, sem revelar se foi o e-mail ou a senha.
- **E-mail único** (duplicado → 400), normalizado em minúsculas; senha com mínimo de 6 caracteres; **nunca é devolvida** e é guardada só como hash bcrypt.
- **Opções do produto:** aceita `values` ou `value` (o escopo usa os dois) e `radius` como `4` ou `"4px"`. No banco os valores ficam em texto separado por vírgula; na API voltam como lista (por isso um valor não pode conter vírgula).
- **`price_with_discount` é obrigatório** (como no escopo); use `0` quando não houver desconto.
- **Imagens:** chegam em base64, são gravadas em `uploads/product-<id>/` com nome aleatório e servidas em `/media`. Tipos aceitos: png, jpeg/jpg, gif, webp. Limite do corpo da requisição: 10 MB.
- **Transações:** criar/atualizar/remover produto é "tudo ou nada"; arquivos órfãos são apagados se algo falhar.
- **Respostas de criação (201)** devolvem o recurso criado (com `id`); `PUT`/`DELETE` devolvem 204 sem corpo.

## 11. Problemas comuns

| Sintoma | Causa provável / solução |
|---|---|
| `Não foi possível conectar ao banco` | MySQL desligado ou `.env` com dados errados. |
| `Unknown database` | Rode `npm run db:create`. |
| `Table ... doesn't exist` | Rode `npm run db:migrate`. |
| `Access denied for user` | Confira `DB_USER`/`DB_PASS`. |
| `401 Token inválido ou expirado` | Gere um novo em `/v1/user/token`; confira o prefixo `Bearer `. |
| `400 Cabeçalho "Authorization..."` | Faltou enviar `Authorization: Bearer <token>`. |
| Filtro `option[45]` não funciona no curl | Use `curl -g`. |
| `EADDRINUSE` | A porta já está em uso: mude `PORT` no `.env`. |

## 12. Checklist dos critérios de aprovação

- **Completeness** — todos os endpoints do escopo, CRUD completo, JWT nos POST/PUT/DELETE, status HTTP conforme o escopo.
- **Code Quality** — camadas separadas, código comentado linha a linha, validação centralizada, erros tratados em um só lugar, testes automatizados.
- **Database Design** — modelagem normalizada, migrations versionadas, FKs com CASCADE, índices e consultas sem N+1.

### Sugestão de organização (Trello/Jira + Git)
*Setup & banco* → *Usuários + JWT* → *Categorias* → *Produtos* → *Busca/filtros* → *Testes* → *Swagger & README*. Use uma branch por tarefa (`feature/usuarios`, `feature/produtos`...) e abra *Pull Request* para code review antes do merge na `main`.

## 13. Como publicar no GitHub

1. Crie um repositório vazio no GitHub (sem README).
2. Na pasta do projeto:
```bash
git init
git add .
git commit -m "feat: API da loja (usuários, categorias, produtos, JWT, Swagger, testes)"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/projeto-backend.git
git push -u origin main
```
3. Confira que o `.env` **não** subiu (ele está no `.gitignore`; só o `.env.example` vai).
4. No GitHub, em **About → ⚙️**, cole a descrição: *"API REST de loja virtual com Node.js, Express, Sequelize, MySQL e JWT — usuários, categorias e produtos, com Swagger e testes."* e os tópicos: `nodejs`, `express`, `sequelize`, `mysql`, `jwt`, `swagger`, `jest`, `rest-api`.

## Licença
MIT
