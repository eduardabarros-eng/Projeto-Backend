// Mapa de URLs de usuários → controllers. Montado em /v1/user.
const { Router } = require('express'); // cria um agrupador de rotas
const auth = require('../middleware/auth'); // exige JWT
const c = require('../controllers/userController');

const router = Router();
router.post('/token', c.token); // público: gera o JWT (declarada antes de "/:id")
router.post('/', c.create); // público: cadastro (senão ninguém conseguiria o primeiro acesso)
router.get('/:id', c.get); // público, conforme o escopo
router.put('/:id', auth, c.update); // protegido
router.delete('/:id', auth, c.remove); // protegido

module.exports = router;
