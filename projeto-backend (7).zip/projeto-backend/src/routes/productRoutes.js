// Mapa de URLs de produtos → controllers. Montado em /v1/product.
const { Router } = require('express');
const auth = require('../middleware/auth'); // exige JWT
const c = require('../controllers/productController');

const router = Router();
router.get('/search', c.search); // público
router.get('/:id', c.get); // público
router.post('/', auth, c.create); // protegido
router.put('/:id', auth, c.update); // protegido
router.delete('/:id', auth, c.remove); // protegido

module.exports = router;
