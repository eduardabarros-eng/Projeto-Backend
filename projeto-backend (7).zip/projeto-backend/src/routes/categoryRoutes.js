// Mapa de URLs de categorias → controllers. Montado em /v1/category.
const { Router } = require('express');
const auth = require('../middleware/auth'); // exige JWT
const c = require('../controllers/categoryController');

const router = Router();
router.get('/search', c.search); // público (antes de "/:id" para "search" não virar id)
router.get('/:id', c.get); // público
router.post('/', auth, c.create); // protegido
router.put('/:id', auth, c.update); // protegido
router.delete('/:id', auth, c.remove); // protegido

module.exports = router;
