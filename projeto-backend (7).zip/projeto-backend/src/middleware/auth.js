// Middleware de autenticação: exige "Authorization: Bearer <jwt>" e valida o token.
const jwt = require('jsonwebtoken'); // biblioteca de JWT
const jwtConfig = require('../config/jwt'); // segredo do token
const AppError = require('../utils/AppError'); // erro com status HTTP

module.exports = function auth(req, res, next) {
  const header = req.headers.authorization; // valor bruto do cabeçalho
  // Seção 05, Requisito 02: sem o cabeçalho "Bearer <jwt>" a resposta é 400
  if (!header || !/^Bearer\s+\S+$/i.test(header)) {
    return next(AppError.badRequest('Cabeçalho "Authorization: Bearer <token>" é obrigatório.'));
  }
  const token = header.split(/\s+/)[1]; // pega só o token, sem "Bearer"
  try {
    const payload = jwt.verify(token, jwtConfig.secret()); // confere assinatura e validade
    req.userId = Number(payload.sub); // guarda quem está logado para uso posterior
    return next(); // segue para o controller
  } catch (err) {
    return next(AppError.unauthorized('Token inválido ou expirado.')); // token falso/expirado → 401
  }
};
