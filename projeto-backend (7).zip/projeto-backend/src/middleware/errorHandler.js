// Middleware final: transforma qualquer erro em uma resposta JSON { message } com o status correto.
module.exports = function errorHandler(err, req, res, next) { // eslint-disable-line no-unused-vars
  // Erros previstos (AppError) já trazem o status
  if (err.isAppError) return res.status(err.status).json({ message: err.message });
  // JSON malformado enviado pelo cliente
  if (err.type === 'entity.parse.failed') return res.status(400).json({ message: 'JSON inválido no corpo da requisição.' });
  // Corpo grande demais (imagens base64 acima do limite)
  if (err.type === 'entity.too.large') return res.status(413).json({ message: 'Corpo da requisição grande demais.' });
  // Violações de unicidade/validação do Sequelize significam dados inválidos do cliente
  if (err.name === 'SequelizeUniqueConstraintError' || err.name === 'SequelizeValidationError') {
    return res.status(400).json({ message: 'Dados inválidos ou já cadastrados.' });
  }
  // Qualquer outra coisa é bug/falha interna: registra no servidor e responde genérico
  console.error(err);
  return res.status(500).json({ message: 'Erro interno do servidor.' });
};
