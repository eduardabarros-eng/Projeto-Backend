// Model da tabela de ligação "product_categories" (Requisito 06 da Seção 01): relação N-N produto x categoria.
module.exports = (sequelize, DataTypes) =>
  sequelize.define(
    'ProductCategory',
    {
      product_id: { type: DataTypes.INTEGER, allowNull: false, primaryKey: true }, // FK + parte da chave composta
      category_id: { type: DataTypes.INTEGER, allowNull: false, primaryKey: true }, // FK + parte da chave composta
    },
    { tableName: 'product_categories', timestamps: false }
  );
