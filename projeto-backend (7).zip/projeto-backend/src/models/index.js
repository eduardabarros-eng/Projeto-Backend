// Ponto central dos models: cria a conexão, registra os models e define os relacionamentos.
const { Sequelize, DataTypes } = require('sequelize'); // classe de conexão e tipos de dados
const dbConfig = require('../config/database'); // credenciais por ambiente

const env = process.env.NODE_ENV || 'development'; // ambiente atual
const sequelize = new Sequelize(dbConfig[env]); // prepara a conexão (só conecta de fato na 1ª query)

// Registra cada model passando a conexão e os tipos de dados
const User = require('./User')(sequelize, DataTypes);
const Category = require('./Category')(sequelize, DataTypes);
const Product = require('./Product')(sequelize, DataTypes);
const ProductImage = require('./ProductImage')(sequelize, DataTypes);
const ProductOption = require('./ProductOption')(sequelize, DataTypes);
const ProductCategory = require('./ProductCategory')(sequelize, DataTypes);

// Produto 1 — N imagens. ON DELETE CASCADE: apagar o produto apaga as imagens
Product.hasMany(ProductImage, { as: 'images', foreignKey: 'product_id', onDelete: 'CASCADE' });
ProductImage.belongsTo(Product, { foreignKey: 'product_id', onDelete: 'CASCADE' });

// Produto 1 — N opções, também com CASCADE
Product.hasMany(ProductOption, { as: 'options', foreignKey: 'product_id', onDelete: 'CASCADE' });
ProductOption.belongsTo(Product, { foreignKey: 'product_id', onDelete: 'CASCADE' });

// Produto N — N categorias pela tabela product_categories (FKs com CASCADE)
ProductCategory.belongsTo(Product, { foreignKey: 'product_id', onDelete: 'CASCADE' });
ProductCategory.belongsTo(Category, { foreignKey: 'category_id', onDelete: 'CASCADE' });

module.exports = { sequelize, Sequelize, User, Category, Product, ProductImage, ProductOption, ProductCategory };
