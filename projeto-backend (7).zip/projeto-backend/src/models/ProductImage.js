// Model da tabela "product_images" (Requisito 04 da Seção 01).
module.exports = (sequelize, DataTypes) =>
  sequelize.define(
    'ProductImage',
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true }, // chave primária
      product_id: { type: DataTypes.INTEGER, allowNull: false }, // FK para products.id
      enabled: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false }, // imagem habilitada?
      path: { type: DataTypes.STRING, allowNull: false }, // caminho relativo do arquivo no servidor
    },
    { tableName: 'product_images', timestamps: false } // a tabela do escopo não tem created_at/updated_at
  );
