// Model da tabela "products" (Requisito 03 da Seção 01).
module.exports = (sequelize, DataTypes) =>
  sequelize.define(
    'Product',
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true }, // chave primária
      enabled: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false }, // habilitado (1) ou não (0)
      name: { type: DataTypes.STRING, allowNull: false }, // nome do produto
      slug: { type: DataTypes.STRING, allowNull: false }, // slug do produto
      use_in_menu: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false }, // pode aparecer no menu
      stock: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 }, // quantidade em estoque
      description: { type: DataTypes.STRING(1000), allowNull: true }, // descrição (opcional)
      price: { type: DataTypes.FLOAT, allowNull: false }, // preço
      price_with_discount: { type: DataTypes.FLOAT, allowNull: false }, // preço com desconto
    },
    { tableName: 'products', timestamps: true, underscored: true }
  );
