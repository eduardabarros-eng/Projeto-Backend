// Model da tabela "users" (Requisito 01 da Seção 01).
module.exports = (sequelize, DataTypes) =>
  sequelize.define(
    'User', // nome do model no código
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true }, // chave primária auto-incrementada
      firstname: { type: DataTypes.STRING, allowNull: false }, // primeiro nome (obrigatório)
      surname: { type: DataTypes.STRING, allowNull: false }, // sobrenome (obrigatório)
      email: { type: DataTypes.STRING, allowNull: false, unique: true }, // e-mail único (obrigatório)
      password: { type: DataTypes.STRING, allowNull: false }, // hash bcrypt da senha (nunca a senha pura)
    },
    {
      tableName: 'users', // nome real da tabela
      timestamps: true, // cria created_at e updated_at
      underscored: true, // usa snake_case nas colunas de data
    }
  );
