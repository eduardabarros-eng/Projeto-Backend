// Model da tabela "product_options" (Requisito 05 da Seção 01).
module.exports = (sequelize, DataTypes) =>
  sequelize.define(
    'ProductOption',
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true }, // chave primária
      product_id: { type: DataTypes.INTEGER, allowNull: false }, // FK para products.id
      title: { type: DataTypes.STRING, allowNull: false }, // título da opção (ex.: "Tamanho")
      shape: { type: DataTypes.ENUM('square', 'circle'), allowNull: false, defaultValue: 'square' }, // formato visual
      radius: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 }, // border-radius em px
      type: { type: DataTypes.ENUM('text', 'color'), allowNull: false, defaultValue: 'text' }, // tipo do input
      values: { type: DataTypes.STRING(1000), allowNull: false }, // valores separados por vírgula ("PP,M,GG")
    },
    { tableName: 'product_options', timestamps: false }
  );
