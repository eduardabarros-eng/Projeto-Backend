// Model da tabela "categories" (Requisito 02 da Seção 01).
module.exports = (sequelize, DataTypes) =>
  sequelize.define(
    'Category',
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true }, // chave primária
      name: { type: DataTypes.STRING, allowNull: false }, // nome da categoria
      slug: { type: DataTypes.STRING, allowNull: false }, // slug (nome amigável para URL)
      use_in_menu: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false }, // aparece no menu? padrão 0
    },
    { tableName: 'categories', timestamps: true, underscored: true }
  );
