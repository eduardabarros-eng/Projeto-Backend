// Controller de categorias.
const service = require('../services/categoryService'); // regras de negócio
const { parseId } = require('../utils/validators'); // converte o :id da URL

module.exports = {
  // GET /v1/category/search → 200 { data, total, limit, page }
  search: async (req, res) => res.status(200).json(await service.search(req.query)),
  // GET /v1/category/:id → 200
  get: async (req, res) => res.status(200).json(await service.getById(parseId(req.params.id))),
  // POST /v1/category → 201
  create: async (req, res) => res.status(201).json(await service.create(req.body)),
  // PUT /v1/category/:id → 204
  update: async (req, res) => { await service.update(parseId(req.params.id), req.body); res.status(204).end(); },
  // DELETE /v1/category/:id → 204
  remove: async (req, res) => { await service.remove(parseId(req.params.id)); res.status(204).end(); },
};
