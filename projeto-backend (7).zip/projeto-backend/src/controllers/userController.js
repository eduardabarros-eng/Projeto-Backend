// Controller de usuários: traduz HTTP (req/res) em chamadas ao service e define o status de sucesso.
const service = require('../services/userService'); // regras de negócio
const { parseId } = require('../utils/validators'); // converte o :id da URL

module.exports = {
  // POST /v1/user/token → 200 { token }
  token: async (req, res) => res.status(200).json(await service.login(req.body)),
  // POST /v1/user → 201 com o usuário criado
  create: async (req, res) => res.status(201).json(await service.create(req.body)),
  // GET /v1/user/:id → 200
  get: async (req, res) => res.status(200).json(await service.getById(parseId(req.params.id))),
  // PUT /v1/user/:id → 204 sem corpo
  update: async (req, res) => { await service.update(parseId(req.params.id), req.body); res.status(204).end(); },
  // DELETE /v1/user/:id → 204 sem corpo
  remove: async (req, res) => { await service.remove(parseId(req.params.id)); res.status(204).end(); },
};
