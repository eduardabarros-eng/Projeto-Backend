// Controller de produtos.
const service = require('../services/productService'); // regras de negócio
const { parseId } = require('../utils/validators'); // converte o :id da URL

module.exports = {
  // GET /v1/product/search → 200 { data, total, limit, page }
  search: async (req, res) => res.status(200).json(await service.search(req.query)),
  // GET /v1/product/:id → 200
  get: async (req, res) => res.status(200).json(await service.getById(parseId(req.params.id))),
  // POST /v1/product → 201
  create: async (req, res) => res.status(201).json(await service.create(req.body)),
  // PUT /v1/product/:id → 204
  update: async (req, res) => { await service.update(parseId(req.params.id), req.body); res.status(204).end(); },
  // DELETE /v1/product/:id → 204
  remove: async (req, res) => { await service.remove(parseId(req.params.id)); res.status(204).end(); },
};
