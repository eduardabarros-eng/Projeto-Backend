// Grava e apaga no disco as imagens dos produtos (recebidas em base64).
const fs = require('fs/promises'); // sistema de arquivos com Promises
const path = require('path'); // montagem de caminhos
const crypto = require('crypto'); // nomes aleatórios
const { uploadDir, baseUrl, allowedTypes } = require('../config/upload'); // configurações de upload
const AppError = require('../utils/AppError'); // erros com status HTTP

// Extensão de arquivo para um MIME aceito (ou 400)
function extensionFor(type) {
  const ext = allowedTypes[String(type).toLowerCase()];
  if (!ext) throw AppError.badRequest(`Tipo de imagem não suportado. Use: ${Object.keys(allowedTypes).join(', ')}.`);
  return ext;
}

// Remove o prefixo "data:image/png;base64," caso o cliente envie e confere se é base64 válido
function cleanBase64(content) {
  if (typeof content !== 'string' || content.trim() === '') throw AppError.badRequest('O campo "content" da imagem é obrigatório.');
  const raw = content.replace(/^data:[^;]+;base64,/, '').replace(/\s/g, '');
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(raw) || raw.length % 4 === 1) throw AppError.badRequest('O campo "content" da imagem deve estar em base64 válido.');
  return raw;
}

// Verdadeiro se o conteúdo é uma URL (o cliente reenviou a imagem atual sem mudar nada)
const isUrl = (content) => typeof content === 'string' && /^https?:\/\//i.test(content);

// Grava a imagem em uploads/product-<id>/<aleatório>.<ext> e devolve o caminho relativo
async function save(productId, type, content) {
  const ext = extensionFor(type);
  const buffer = Buffer.from(cleanBase64(content), 'base64'); // decodifica o base64
  if (buffer.length === 0) throw AppError.badRequest('A imagem enviada está vazia.');
  const folder = `product-${productId}`; // pasta do produto
  const relative = `${folder}/${crypto.randomBytes(12).toString('hex')}.${ext}`; // nome aleatório evita colisão
  await fs.mkdir(path.join(uploadDir(), folder), { recursive: true }); // cria a pasta se preciso
  await fs.writeFile(path.join(uploadDir(), relative), buffer); // grava o arquivo
  return relative;
}

// Apaga um arquivo (ignora se já não existir)
async function remove(relative) {
  await fs.rm(path.join(uploadDir(), relative), { force: true });
}

// Apaga a pasta inteira do produto
async function removeProductFolder(productId) {
  await fs.rm(path.join(uploadDir(), `product-${productId}`), { recursive: true, force: true });
}

// Monta a URL pública da imagem: BASE_URL/media/<caminho relativo>
const toUrl = (relative) => `${baseUrl()}/media/${relative}`;

// Extensão do caminho salvo (usada quando o PUT troca o arquivo sem informar o type)
const typeFromPath = (relative) => {
  const ext = path.extname(relative).slice(1);
  return Object.keys(allowedTypes).find((t) => allowedTypes[t] === ext) || 'image/png';
};

module.exports = { save, remove, removeProductFolder, toUrl, isUrl, typeFromPath, extensionFor, cleanBase64 };
