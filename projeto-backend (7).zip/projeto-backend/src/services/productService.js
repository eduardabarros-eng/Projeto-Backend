// Regras de negócio dos produtos: validação, busca com filtros, CRUD transacional, imagens e opções.
const { Op } = require('sequelize'); // operadores SQL (IN, BETWEEN, LIKE...)
const { sequelize, Product, ProductImage, ProductOption, ProductCategory, Category } = require('../models');
const images = require('./imageStorage'); // gravação de imagens no disco
const AppError = require('../utils/AppError'); // erros com status HTTP
const v = require('../utils/validators'); // validadores
const { parsePagination, parseFields, pickFields } = require('../utils/pagination'); // paginação e fields

// Campos que podem ser pedidos em "fields" na busca
const FIELDS = ['id', 'enabled', 'name', 'slug', 'use_in_menu', 'stock', 'description', 'price', 'price_with_discount', 'category_ids', 'images', 'options'];
const SHAPES = ['square', 'circle']; // formatos válidos de opção
const OPTION_TYPES = ['text', 'color']; // tipos válidos de opção

/* ===================== SERIALIZAÇÃO ===================== */

// Converte um produto (com images/options carregadas) no JSON da API
function serialize(p, categoryIds) {
  return {
    id: p.id,
    enabled: Boolean(p.enabled),
    name: p.name,
    slug: p.slug,
    use_in_menu: Boolean(p.use_in_menu),
    stock: p.stock,
    description: p.description,
    price: p.price,
    price_with_discount: p.price_with_discount,
    category_ids: categoryIds,
    images: (p.images || []).map((i) => ({ id: i.id, content: images.toUrl(i.path) })), // path vira URL pública
    options: (p.options || []).map((o) => ({
      id: o.id, title: o.title, shape: o.shape, radius: o.radius, type: o.type,
      values: o.values.split(','), // no banco é "PP,M,GG"; na API volta como lista
    })),
  };
}

// Carrega vários produtos de uma vez com 3 consultas fixas (produtos+imagens+opções, e categorias): sem N+1
async function loadMany(ids, transaction) {
  if (ids.length === 0) return [];
  const products = await Product.findAll({
    where: { id: { [Op.in]: ids } },
    include: [{ model: ProductImage, as: 'images' }, { model: ProductOption, as: 'options' }],
    order: [[{ model: ProductImage, as: 'images' }, 'id', 'ASC'], [{ model: ProductOption, as: 'options' }, 'id', 'ASC']],
    transaction,
  });
  const links = await ProductCategory.findAll({ where: { product_id: { [Op.in]: ids } }, transaction });
  const byId = new Map(products.map((p) => [p.id, p])); // acesso rápido por id
  return ids.filter((id) => byId.has(id)).map((id) => // mantém a ordem pedida
    serialize(byId.get(id), links.filter((l) => l.product_id === id).map((l) => l.category_id).sort((a, b) => a - b)));
}

// Busca um produto pelo id ou lança 404
async function getById(id, transaction) {
  const [product] = id ? await loadMany([id], transaction) : [];
  if (!product) throw AppError.notFound('Produto não encontrado.');
  return product;
}

/* ===================== VALIDAÇÃO DO PAYLOAD ===================== */

// "4px" ou 4 → 4 (inteiro >= 0)
function parseRadius(value) {
  if (typeof value === 'number' && Number.isInteger(value) && value >= 0) return value;
  if (typeof value === 'string' && /^\d+(px)?$/.test(value.trim())) return parseInt(value, 10);
  throw AppError.badRequest('O campo "radius" deve ser um inteiro maior ou igual a zero (ex.: 4 ou "4px").');
}

// Valida a lista de valores de uma opção (aceita "values" ou "value")
function parseValues(item) {
  const list = item.values !== undefined ? item.values : item.value;
  if (!Array.isArray(list) || list.length === 0 || list.some((x) => typeof x !== 'string' || x.trim() === '' || x.includes(','))) {
    throw AppError.badRequest('As opções devem ter "values" como lista de textos não vazios e sem vírgula.');
  }
  return list.map((x) => x.trim()).join(','); // guardado como texto separado por vírgula
}

// Valida a lista "images". No POST só cria; no PUT cria, atualiza ou remove
function parseImages(list, allowIdOps) {
  if (!Array.isArray(list)) throw AppError.badRequest('O campo "images" deve ser uma lista.');
  return list.map((item) => {
    v.ensureObject(item);
    if (item === null || typeof item !== 'object') throw AppError.badRequest('Cada imagem deve ser um objeto.');
    if (item.id === undefined) { // sem id → cria
      images.extensionFor(item.type); // valida o tipo
      images.cleanBase64(item.content); // valida o base64
      return { op: 'create', type: item.type, content: item.content };
    }
    if (!allowIdOps) throw AppError.badRequest('Ao criar um produto, as imagens não devem ter "id".');
    if (!Number.isInteger(item.id) || item.id <= 0) throw AppError.badRequest('O "id" da imagem deve ser um inteiro positivo.');
    if (item.deleted === true) return { op: 'delete', id: item.id }; // remove
    const op = { op: 'update', id: item.id }; // atualiza
    if (item.content !== undefined) {
      if (!images.isUrl(item.content)) images.cleanBase64(item.content); // URL = manter; base64 = trocar arquivo
      op.content = item.content;
      if (item.type !== undefined) { images.extensionFor(item.type); op.type = item.type; }
    }
    if (item.enabled !== undefined) op.enabled = v.toBoolean(item.enabled, 'enabled');
    return op;
  });
}

// Valida a lista "options" (mesma lógica de criar/atualizar/remover)
function parseOptions(list, allowIdOps) {
  if (!Array.isArray(list)) throw AppError.badRequest('O campo "options" deve ser uma lista.');
  return list.map((item) => {
    if (item === null || typeof item !== 'object' || Array.isArray(item)) throw AppError.badRequest('Cada opção deve ser um objeto.');
    const isUpdate = item.id !== undefined;
    if (isUpdate && !allowIdOps) throw AppError.badRequest('Ao criar um produto, as opções não devem ter "id".');
    if (isUpdate && (!Number.isInteger(item.id) || item.id <= 0)) throw AppError.badRequest('O "id" da opção deve ser um inteiro positivo.');
    if (isUpdate && item.deleted === true) return { op: 'delete', id: item.id };
    const out = { op: isUpdate ? 'update' : 'create' };
    if (isUpdate) out.id = item.id;
    if (!isUpdate || item.title !== undefined) out.title = v.requireString(item.title, 'title'); // obrigatório só ao criar
    if (item.shape !== undefined) {
      if (!SHAPES.includes(item.shape)) throw AppError.badRequest('O campo "shape" deve ser "square" ou "circle".');
      out.shape = item.shape;
    }
    if (item.radius !== undefined) out.radius = parseRadius(item.radius);
    if (item.type !== undefined) {
      if (!OPTION_TYPES.includes(item.type)) throw AppError.badRequest('O campo "type" da opção deve ser "text" ou "color".');
      out.type = item.type;
    }
    if (!isUpdate || item.values !== undefined || item.value !== undefined) out.values = parseValues(item); // obrigatório ao criar
    return out;
  });
}

// Valida o corpo inteiro do produto. partial=true (PUT): todos os campos são opcionais
function validate(body, partial) {
  const data = v.ensureObject(body);
  const fields = {}; // colunas da tabela products
  if (!partial || v.has(data, 'name')) fields.name = v.requireString(data.name, 'name');
  if (!partial || v.has(data, 'slug')) fields.slug = v.requireString(data.slug, 'slug');
  if (!partial || v.has(data, 'price')) fields.price = v.toNonNegativeNumber(data.price, 'price');
  if (!partial || v.has(data, 'price_with_discount')) fields.price_with_discount = v.toNonNegativeNumber(data.price_with_discount, 'price_with_discount');
  if (v.has(data, 'enabled')) fields.enabled = v.toBoolean(data.enabled, 'enabled');
  if (v.has(data, 'use_in_menu')) fields.use_in_menu = v.toBoolean(data.use_in_menu, 'use_in_menu');
  if (v.has(data, 'stock')) fields.stock = v.toNonNegativeInt(data.stock, 'stock');
  if (v.has(data, 'description')) {
    if (data.description !== null && typeof data.description !== 'string') throw AppError.badRequest('O campo "description" deve ser um texto.');
    if (data.description && data.description.length > 1000) throw AppError.badRequest('O campo "description" deve ter no máximo 1000 caracteres.');
    fields.description = data.description;
  }
  return {
    fields,
    categoryIds: v.has(data, 'category_ids') ? v.toIdList(data.category_ids, 'category_ids') : undefined,
    imageOps: v.has(data, 'images') ? parseImages(data.images, partial) : undefined,
    optionOps: v.has(data, 'options') ? parseOptions(data.options, partial) : undefined,
  };
}

/* ===================== ESCRITA (dentro de transação) ===================== */

// Confere se todas as categorias existem e substitui a lista do produto
async function setCategories(productId, ids, t) {
  if (ids.length) {
    const found = await Category.count({ where: { id: { [Op.in]: ids } }, transaction: t });
    if (found !== ids.length) throw AppError.badRequest('Um ou mais "category_ids" não existem.');
  }
  await ProductCategory.destroy({ where: { product_id: productId }, transaction: t }); // limpa as ligações atuais
  await ProductCategory.bulkCreate(ids.map((category_id) => ({ product_id: productId, category_id })), { transaction: t });
}

// Aplica criar/atualizar/remover imagens. "track" registra arquivos para limpeza (rollback ou pós-commit)
async function applyImages(productId, ops, t, track) {
  for (const op of ops) {
    if (op.op === 'create') {
      const path = await images.save(productId, op.type, op.content);
      track.created.push(path); // se a transação falhar, este arquivo é apagado
      await ProductImage.create({ product_id: productId, enabled: true, path }, { transaction: t });
      continue;
    }
    const current = await ProductImage.findOne({ where: { id: op.id, product_id: productId }, transaction: t });
    if (!current) throw AppError.badRequest(`A imagem ${op.id} não pertence a este produto.`);
    if (op.op === 'delete') {
      await current.destroy({ transaction: t });
      track.obsolete.push(current.path); // arquivo antigo só some depois do commit
      continue;
    }
    const changes = {};
    if (op.enabled !== undefined) changes.enabled = op.enabled;
    if (op.content !== undefined && !images.isUrl(op.content)) { // base64 novo → troca o arquivo
      changes.path = await images.save(productId, op.type || images.typeFromPath(current.path), op.content);
      track.created.push(changes.path);
      track.obsolete.push(current.path);
    }
    if (Object.keys(changes).length) await current.update(changes, { transaction: t });
  }
}

// Aplica criar/atualizar/remover opções
async function applyOptions(productId, ops, t) {
  for (const op of ops) {
    if (op.op === 'create') {
      const { op: _ignored, ...data } = op; // tira o campo "op" interno
      await ProductOption.create({ ...data, product_id: productId }, { transaction: t });
      continue;
    }
    const current = await ProductOption.findOne({ where: { id: op.id, product_id: productId }, transaction: t });
    if (!current) throw AppError.badRequest(`A opção ${op.id} não pertence a este produto.`);
    if (op.op === 'delete') { await current.destroy({ transaction: t }); continue; }
    const { op: _ignored, id: _id, ...changes } = op;
    if (Object.keys(changes).length) await current.update(changes, { transaction: t });
  }
}

/* ===================== OPERAÇÕES PÚBLICAS ===================== */

// POST /v1/product
async function create(body) {
  const { fields, categoryIds, imageOps, optionOps } = validate(body, false); // valida tudo antes de tocar no banco
  const track = { created: [], obsolete: [] };
  try {
    const id = await sequelize.transaction(async (t) => { // tudo ou nada
      const product = await Product.create(fields, { transaction: t });
      if (imageOps) await applyImages(product.id, imageOps, t, track);
      if (categoryIds) await setCategories(product.id, categoryIds, t); // pode falhar (400) depois das imagens: o catch abaixo limpa os arquivos
      if (optionOps) await applyOptions(product.id, optionOps, t);
      return product.id;
    });
    return await getById(id);
  } catch (err) {
    await Promise.all(track.created.map((p) => images.remove(p))); // desfaz arquivos gravados
    throw err;
  }
}

// PUT /v1/product/:id
async function update(id, body) {
  const product = id ? await Product.findByPk(id) : null;
  if (!product) throw AppError.notFound('Produto não encontrado.');
  const { fields, categoryIds, imageOps, optionOps } = validate(body, true);
  const track = { created: [], obsolete: [] };
  try {
    await sequelize.transaction(async (t) => {
      if (Object.keys(fields).length) await product.update(fields, { transaction: t });
      if (categoryIds) await setCategories(product.id, categoryIds, t); // substitui a lista
      if (imageOps) await applyImages(product.id, imageOps, t, track);
      if (optionOps) await applyOptions(product.id, optionOps, t);
    });
  } catch (err) {
    await Promise.all(track.created.map((p) => images.remove(p)));
    throw err;
  }
  await Promise.all(track.obsolete.map((p) => images.remove(p))); // commit ok: apaga os arquivos antigos
}

// DELETE /v1/product/:id
async function remove(id) {
  const product = id ? await Product.findByPk(id) : null;
  if (!product) throw AppError.notFound('Produto não encontrado.');
  await sequelize.transaction((t) => product.destroy({ transaction: t })); // CASCADE limpa imagens, opções e ligações
  await images.removeProductFolder(product.id); // apaga os arquivos
}

/* ===================== BUSCA ===================== */

// Lê "category_ids=1,2" em lista de inteiros
function parseCategoryIds(raw) {
  if (typeof raw !== 'string' || !/^\d+(,\d+)*$/.test(raw)) throw AppError.badRequest('O parâmetro "category_ids" deve ser ids separados por vírgula (ex.: 1,2).');
  return raw.split(',').map(Number);
}

// Lê "price-range=100-200" em [min, max]
function parsePriceRange(raw) {
  const m = typeof raw === 'string' && raw.match(/^(\d+(?:\.\d+)?)-(\d+(?:\.\d+)?)$/);
  if (!m || Number(m[1]) > Number(m[2])) throw AppError.badRequest('O parâmetro "price-range" deve ser "min-max" (ex.: 100-200), com min <= max.');
  return [Number(m[1]), Number(m[2])];
}

// GET /v1/product/search
async function search(query) {
  const { limit, page, all, offset } = parsePagination(query);
  const fields = parseFields(query.fields, FIELDS);
  const where = {}; // filtros diretos na tabela products
  const idSets = []; // conjuntos de ids vindos de filtros em outras tabelas (interseção)

  if (query.match !== undefined) { // termo no nome OU descrição
    if (typeof query.match !== 'string' || !query.match.trim()) throw AppError.badRequest('O parâmetro "match" deve ser um texto.');
    const like = { [Op.like]: `%${query.match.trim()}%` };
    where[Op.or] = [{ name: like }, { description: like }];
  }
  if (query['price-range'] !== undefined) where.price = { [Op.between]: parsePriceRange(query['price-range']) };
  if (query.category_ids !== undefined) { // produtos de QUALQUER das categorias
    const links = await ProductCategory.findAll({ where: { category_id: { [Op.in]: parseCategoryIds(query.category_ids) } }, attributes: ['product_id'] });
    idSets.push(links.map((l) => l.product_id));
  }
  if (query.option !== undefined) { // option[45]=GG,PP → opção 45 contém GG ou PP
    if (typeof query.option !== 'object' || Array.isArray(query.option)) throw AppError.badRequest('Use o formato option[ID]=valor1,valor2.');
    for (const [optionId, raw] of Object.entries(query.option)) {
      if (!/^\d+$/.test(optionId) || typeof raw !== 'string' || !raw.trim()) throw AppError.badRequest('Use o formato option[ID]=valor1,valor2.');
      const wanted = raw.split(',').map((x) => x.trim());
      const rows = await ProductOption.findAll({ where: { id: Number(optionId) } });
      idSets.push(rows.filter((o) => o.values.split(',').some((val) => wanted.includes(val))).map((o) => o.product_id));
    }
  }
  if (idSets.length) { // todos os filtros precisam ser atendidos → interseção dos conjuntos
    const common = idSets.reduce((acc, set) => acc.filter((id) => set.includes(id)));
    where.id = { [Op.in]: common };
  }

  // 1ª consulta: só os ids da página + total (paginação correta, sem JOIN multiplicando linhas)
  const { rows, count } = await Product.findAndCountAll({ where, attributes: ['id'], order: [['id', 'ASC']], ...(all ? {} : { limit, offset }) });
  // 2ª etapa: carrega os relacionamentos em lote
  const data = await loadMany(rows.map((r) => r.id));
  return { data: data.map((p) => pickFields(p, fields)), total: count, limit, page };
}

module.exports = { search, getById, create, update, remove };
