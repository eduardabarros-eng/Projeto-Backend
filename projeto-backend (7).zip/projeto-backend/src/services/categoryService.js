// Regras de negócio das categorias.
const { Category } = require('../models'); // model da tabela categories
const AppError = require('../utils/AppError'); // erros com status HTTP
const v = require('../utils/validators'); // validadores
const { parsePagination, parseFields, pickFields } = require('../utils/pagination'); // paginação e fields

const FIELDS = ['id', 'name', 'slug', 'use_in_menu']; // campos que a API expõe

// Converte a linha do banco no JSON da API
const toJSON = (c) => ({ id: c.id, name: c.name, slug: c.slug, use_in_menu: Boolean(c.use_in_menu) });

// Busca a categoria ou lança 404
async function findOrFail(id) {
  const category = id ? await Category.findByPk(id) : null;
  if (!category) throw AppError.notFound('Categoria não encontrada.');
  return category;
}

// GET /v1/category/search
async function search(query) {
  const { limit, page, all, offset } = parsePagination(query);
  const fields = parseFields(query.fields, FIELDS);
  const where = {}; // filtros do SQL
  if (query.use_in_menu !== undefined) where.use_in_menu = v.toBoolean(query.use_in_menu, 'use_in_menu');
  // Uma única consulta devolve a página e o total (COUNT) — sem N+1
  const { rows, count } = await Category.findAndCountAll({
    where,
    order: [['id', 'ASC']],
    ...(all ? {} : { limit, offset }), // com limit=-1 não limita
  });
  return { data: rows.map((c) => pickFields(toJSON(c), fields)), total: count, limit, page };
}

// GET /v1/category/:id
async function getById(id) {
  return toJSON(await findOrFail(id));
}

// Valida o payload; no PUT os campos são opcionais, no POST name e slug são obrigatórios
function validate(body, partial) {
  const data = v.ensureObject(body);
  const out = {};
  if (!partial || v.has(data, 'name')) out.name = v.requireString(data.name, 'name');
  if (!partial || v.has(data, 'slug')) out.slug = v.requireString(data.slug, 'slug');
  if (v.has(data, 'use_in_menu')) out.use_in_menu = v.toBoolean(data.use_in_menu, 'use_in_menu');
  if (partial && Object.keys(out).length === 0) throw AppError.badRequest('Envie ao menos um campo: name, slug ou use_in_menu.');
  return out;
}

// POST /v1/category
async function create(body) {
  return toJSON(await Category.create(validate(body, false)));
}

// PUT /v1/category/:id
async function update(id, body) {
  const category = await findOrFail(id);
  await category.update(validate(body, true));
}

// DELETE /v1/category/:id (a tabela de ligação limpa sozinha via ON DELETE CASCADE)
async function remove(id) {
  const category = await findOrFail(id);
  await category.destroy();
}

module.exports = { search, getById, create, update, remove };
