// Regras de negócio de usuários e do login (JWT).
const bcrypt = require('bcrypt'); // gera/compara hash de senha
const jwt = require('jsonwebtoken'); // gera o token
const { User } = require('../models'); // model da tabela users
const jwtConfig = require('../config/jwt'); // segredo e validade do token
const AppError = require('../utils/AppError'); // erros com status HTTP
const v = require('../utils/validators'); // validadores

// Formato público do usuário: nunca devolve a senha
const toPublic = (u) => ({ id: u.id, firstname: u.firstname, surname: u.surname, email: u.email });

// Busca o usuário ou lança 404
async function findOrFail(id) {
  const user = id ? await User.findByPk(id) : null; // id inválido nem consulta o banco
  if (!user) throw AppError.notFound('Usuário não encontrado.');
  return user;
}

// GET /v1/user/:id
async function getById(id) {
  return toPublic(await findOrFail(id));
}

// POST /v1/user — cadastro
async function create(body) {
  const data = v.ensureObject(body);
  const firstname = v.requireString(data.firstname, 'firstname');
  const surname = v.requireString(data.surname, 'surname');
  const email = v.toEmail(data.email);
  const password = v.requireString(data.password, 'password', 100);
  if (password.length < 6) throw AppError.badRequest('A senha deve ter pelo menos 6 caracteres.');
  if (data.confirmPassword !== data.password) throw AppError.badRequest('A confirmação de senha não confere com a senha.');
  if (await User.findOne({ where: { email } })) throw AppError.badRequest('Este e-mail já está cadastrado.');
  const hash = await bcrypt.hash(data.password, 10); // 10 = custo do bcrypt (equilíbrio segurança/velocidade)
  return toPublic(await User.create({ firstname, surname, email, password: hash }));
}

// PUT /v1/user/:id — atualiza nome, sobrenome e/ou e-mail
async function update(id, body) {
  const user = await findOrFail(id);
  const data = v.ensureObject(body);
  const changes = {}; // só entram os campos enviados
  if (v.has(data, 'firstname')) changes.firstname = v.requireString(data.firstname, 'firstname');
  if (v.has(data, 'surname')) changes.surname = v.requireString(data.surname, 'surname');
  if (v.has(data, 'email')) {
    changes.email = v.toEmail(data.email);
    const other = await User.findOne({ where: { email: changes.email } }); // outro usuário com o mesmo e-mail?
    if (other && other.id !== user.id) throw AppError.badRequest('Este e-mail já está cadastrado.');
  }
  if (Object.keys(changes).length === 0) throw AppError.badRequest('Envie ao menos um campo: firstname, surname ou email.');
  await user.update(changes);
}

// DELETE /v1/user/:id
async function remove(id) {
  const user = await findOrFail(id);
  await user.destroy();
}

// POST /v1/user/token — valida e-mail/senha e devolve o JWT
async function login(body) {
  const data = v.ensureObject(body);
  if (typeof data.email !== 'string' || typeof data.password !== 'string' || !data.email || !data.password) {
    throw AppError.badRequest('Informe "email" e "password".');
  }
  const user = await User.findOne({ where: { email: data.email.trim().toLowerCase() } });
  const ok = user && (await bcrypt.compare(data.password, user.password)); // compara senha com o hash
  // Mesma mensagem para e-mail ou senha errados: não revela qual dos dois falhou
  if (!ok) throw AppError.badRequest('E-mail ou senha incorretos.');
  const token = jwt.sign({ sub: String(user.id), email: user.email }, jwtConfig.secret(), { expiresIn: jwtConfig.expiresIn() });
  return { token };
}

module.exports = { getById, create, update, remove, login };
