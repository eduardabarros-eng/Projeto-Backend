// Configurações do armazenamento de imagens dos produtos.
const path = require('path'); // utilitário nativo para montar caminhos
const { currentBaseUrl } = require('../utils/requestContext'); // endereço da requisição atual

// Pasta absoluta onde as imagens são gravadas (função porque o .env pode mudar nos testes)
const uploadDir = () => path.resolve(process.cwd(), process.env.UPLOAD_DIR || 'uploads');

// URL pública base da API, usada para montar o link das imagens.
// Ordem: 1) BASE_URL do .env (recomendado em produção); 2) endereço pelo qual a requisição chegou
// (funciona em qualquer computador/IP/domínio, sem configurar); 3) localhost como último recurso.
const baseUrl = () => {
  const configured = process.env.BASE_URL || currentBaseUrl() || `http://localhost:${process.env.PORT || 3000}`;
  return configured.replace(/\/+$/, ''); // remove "/" final, se houver
};

// Tipos MIME aceitos e a extensão de arquivo correspondente
const allowedTypes = {
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/jpg': 'jpg', // o escopo usa "image/jpg", que não é um MIME oficial, mas aceitamos
  'image/gif': 'gif',
  'image/webp': 'webp',
};

module.exports = { uploadDir, baseUrl, allowedTypes };
