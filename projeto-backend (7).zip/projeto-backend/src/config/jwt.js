// Configurações do JWT (JSON Web Token) usadas para assinar e validar tokens.
// Funções (e não constantes) para ler o .env no momento do uso, inclusive nos testes.
module.exports = {
  // Segredo que assina os tokens; em produção deve ser longo e aleatório
  secret: () => process.env.JWT_SECRET || 'segredo-apenas-para-desenvolvimento',
  // Tempo de vida do token (ex.: 15m, 1h, 7d)
  expiresIn: () => process.env.JWT_EXPIRES_IN || '1h',
};
