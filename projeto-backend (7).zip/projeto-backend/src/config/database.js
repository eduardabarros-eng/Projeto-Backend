// Configuração do banco de dados, lida tanto pelo Sequelize (app) quanto pelo sequelize-cli (migrations).
require('dotenv').config(); // carrega as variáveis do arquivo .env para process.env

// Dados de conexão MySQL, compartilhados entre desenvolvimento e produção
const mysql = {
  username: process.env.DB_USER, // usuário do MySQL
  password: process.env.DB_PASS, // senha do MySQL
  database: process.env.DB_NAME || 'projeto_backend', // nome do banco (se não houver no .env, usa o nome do projeto)
  host: process.env.DB_HOST || 'localhost', // endereço do servidor MySQL
  port: Number(process.env.DB_PORT) || 3306, // porta do MySQL
  dialect: 'mysql', // diz ao Sequelize qual banco usar
  logging: false, // não imprime cada SQL no console
};

// O objeto é indexado pelo ambiente (NODE_ENV); o sequelize-cli escolhe a chave certa
module.exports = {
  development: mysql, // ambiente de desenvolvimento (npm run dev)
  production: mysql, // ambiente de produção (npm start com NODE_ENV=production)
  // Testes usam SQLite em memória: rápido e sem precisar do MySQL
  test: { dialect: 'sqlite', storage: ':memory:', logging: false },
};
