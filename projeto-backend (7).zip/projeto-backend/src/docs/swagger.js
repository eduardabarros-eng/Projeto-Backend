// Especificação OpenAPI 3 da API, exibida pelo Swagger UI em /api-docs.

// Atalho: referência a uma resposta de erro padrão
const err = (description) => ({ description, content: { 'application/json': { schema: { $ref: '#/components/schemas/Error' } } } });
// Atalho: parâmetro de caminho :id
const idParam = { name: 'id', in: 'path', required: true, schema: { type: 'integer' }, description: 'ID do recurso' };
// Atalho: corpo JSON referenciando um schema
const body = (ref) => ({ required: true, content: { 'application/json': { schema: { $ref: `#/components/schemas/${ref}` } } } });
// Atalho: resposta JSON referenciando um schema
const ok = (description, ref) => ({ description, content: { 'application/json': { schema: { $ref: `#/components/schemas/${ref}` } } } });
const secured = [{ bearerAuth: [] }]; // rota exige JWT
// Parâmetros de paginação comuns às buscas
const paging = [
  { name: 'limit', in: 'query', schema: { type: 'integer', default: 12 }, description: 'Itens por página; -1 devolve todos' },
  { name: 'page', in: 'query', schema: { type: 'integer', default: 1 }, description: 'Página (sem efeito com limit=-1)' },
  { name: 'fields', in: 'query', schema: { type: 'string' }, description: 'Campos a retornar, separados por vírgula' },
];

module.exports = {
  openapi: '3.0.3',
  info: {
    title: 'API da Loja — Projeto Back-end',
    version: '1.0.0',
    description: 'API REST de uma loja virtual: usuários, categorias e produtos. Rotas POST/PUT/DELETE exigem `Authorization: Bearer <jwt>` (exceto cadastro e login). Clique em **Authorize** e cole o token obtido em `POST /v1/user/token`.',
  },
  servers: [{ url: '/' }], // mesma origem de onde o Swagger foi aberto
  tags: [{ name: 'Usuários' }, { name: 'Categorias' }, { name: 'Produtos' }, { name: 'Utilitários' }],
  components: {
    securitySchemes: { bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' } },
    schemas: {
      Error: { type: 'object', properties: { message: { type: 'string', example: 'O campo "name" é obrigatório e deve ser um texto.' } } },
      UserCreate: { type: 'object', required: ['firstname', 'surname', 'email', 'password', 'confirmPassword'], properties: { firstname: { type: 'string', example: 'Maria' }, surname: { type: 'string', example: 'Silva' }, email: { type: 'string', example: 'maria@mail.com' }, password: { type: 'string', example: '123@123' }, confirmPassword: { type: 'string', example: '123@123' } } },
      UserUpdate: { type: 'object', properties: { firstname: { type: 'string' }, surname: { type: 'string' }, email: { type: 'string' } } },
      User: { type: 'object', properties: { id: { type: 'integer' }, firstname: { type: 'string' }, surname: { type: 'string' }, email: { type: 'string' } } },
      Login: { type: 'object', required: ['email', 'password'], properties: { email: { type: 'string', example: 'maria@mail.com' }, password: { type: 'string', example: '123@123' } } },
      Token: { type: 'object', properties: { token: { type: 'string' } } },
      CategoryInput: { type: 'object', required: ['name', 'slug'], properties: { name: { type: 'string', example: 'Shoes' }, slug: { type: 'string', example: 'shoes' }, use_in_menu: { type: 'boolean', example: true } } },
      Category: { type: 'object', properties: { id: { type: 'integer' }, name: { type: 'string' }, slug: { type: 'string' }, use_in_menu: { type: 'boolean' } } },
      CategoryList: { type: 'object', properties: { data: { type: 'array', items: { $ref: '#/components/schemas/Category' } }, total: { type: 'integer' }, limit: { type: 'integer' }, page: { type: 'integer' } } },
      ImageInput: { type: 'object', description: 'Sem id cria; {id, deleted:true} remove; {id, content} atualiza (base64 troca o arquivo, URL mantém).', properties: { id: { type: 'integer' }, deleted: { type: 'boolean' }, type: { type: 'string', example: 'image/png' }, content: { type: 'string', description: 'Imagem em base64 (ou URL atual ao atualizar)' } } },
      OptionInput: { type: 'object', description: 'Sem id cria; {id, deleted:true} remove; {id, ...campos} atualiza. Aceita "values" ou "value".', properties: { id: { type: 'integer' }, deleted: { type: 'boolean' }, title: { type: 'string', example: 'Tamanho' }, shape: { type: 'string', enum: ['square', 'circle'] }, radius: { type: 'string', example: '4px' }, type: { type: 'string', enum: ['text', 'color'] }, values: { type: 'array', items: { type: 'string' }, example: ['PP', 'M', 'GG'] } } },
      ProductInput: { type: 'object', required: ['name', 'slug', 'price', 'price_with_discount'], properties: { enabled: { type: 'boolean' }, name: { type: 'string', example: 'Produto 01' }, slug: { type: 'string', example: 'produto-01' }, use_in_menu: { type: 'boolean' }, stock: { type: 'integer', example: 10 }, description: { type: 'string' }, price: { type: 'number', example: 119.9 }, price_with_discount: { type: 'number', example: 99.9 }, category_ids: { type: 'array', items: { type: 'integer' }, example: [1] }, images: { type: 'array', items: { $ref: '#/components/schemas/ImageInput' } }, options: { type: 'array', items: { $ref: '#/components/schemas/OptionInput' } } } },
      Product: { type: 'object', properties: { id: { type: 'integer' }, enabled: { type: 'boolean' }, name: { type: 'string' }, slug: { type: 'string' }, use_in_menu: { type: 'boolean' }, stock: { type: 'integer' }, description: { type: 'string' }, price: { type: 'number' }, price_with_discount: { type: 'number' }, category_ids: { type: 'array', items: { type: 'integer' } }, images: { type: 'array', items: { type: 'object', properties: { id: { type: 'integer' }, content: { type: 'string' } } } }, options: { type: 'array', items: { type: 'object' } } } },
      ProductList: { type: 'object', properties: { data: { type: 'array', items: { $ref: '#/components/schemas/Product' } }, total: { type: 'integer' }, limit: { type: 'integer' }, page: { type: 'integer' } } },
    },
  },
  paths: {
    '/v1/user/token': { post: { tags: ['Usuários'], summary: 'Gera o token JWT (login)', requestBody: body('Login'), responses: { 200: ok('Token gerado', 'Token'), 400: err('E-mail/senha incorretos ou dados inválidos') } } },
    '/v1/user': { post: { tags: ['Usuários'], summary: 'Cadastra usuário', requestBody: body('UserCreate'), responses: { 201: ok('Usuário criado', 'User'), 400: err('Dados inválidos') } } },
    '/v1/user/{id}': {
      get: { tags: ['Usuários'], summary: 'Obtém usuário pelo ID', parameters: [idParam], responses: { 200: ok('Usuário', 'User'), 404: err('Não encontrado') } },
      put: { tags: ['Usuários'], summary: 'Atualiza usuário', security: secured, parameters: [idParam], requestBody: body('UserUpdate'), responses: { 204: { description: 'Atualizado' }, 400: err('Dados inválidos ou token ausente'), 401: err('Token inválido'), 404: err('Não encontrado') } },
      delete: { tags: ['Usuários'], summary: 'Remove usuário', security: secured, parameters: [idParam], responses: { 204: { description: 'Removido' }, 400: err('Token ausente'), 401: err('Token inválido'), 404: err('Não encontrado') } },
    },
    '/v1/category/search': { get: { tags: ['Categorias'], summary: 'Lista categorias', parameters: [...paging, { name: 'use_in_menu', in: 'query', schema: { type: 'boolean' }, description: 'Só categorias do menu' }], responses: { 200: ok('Lista paginada', 'CategoryList'), 400: err('Parâmetros inválidos') } } },
    '/v1/category': { post: { tags: ['Categorias'], summary: 'Cria categoria', security: secured, requestBody: body('CategoryInput'), responses: { 201: ok('Criada', 'Category'), 400: err('Dados inválidos ou token ausente'), 401: err('Token inválido') } } },
    '/v1/category/{id}': {
      get: { tags: ['Categorias'], summary: 'Obtém categoria pelo ID', parameters: [idParam], responses: { 200: ok('Categoria', 'Category'), 404: err('Não encontrada') } },
      put: { tags: ['Categorias'], summary: 'Atualiza categoria', security: secured, parameters: [idParam], requestBody: body('CategoryInput'), responses: { 204: { description: 'Atualizada' }, 400: err('Dados inválidos ou token ausente'), 401: err('Token inválido'), 404: err('Não encontrada') } },
      delete: { tags: ['Categorias'], summary: 'Remove categoria', security: secured, parameters: [idParam], responses: { 204: { description: 'Removida' }, 400: err('Token ausente'), 401: err('Token inválido'), 404: err('Não encontrada') } },
    },
    '/v1/product/search': { get: { tags: ['Produtos'], summary: 'Busca produtos com filtros', parameters: [...paging, { name: 'match', in: 'query', schema: { type: 'string' }, description: 'Termo no nome ou descrição' }, { name: 'category_ids', in: 'query', schema: { type: 'string' }, example: '15,24', description: 'Qualquer dessas categorias' }, { name: 'price-range', in: 'query', schema: { type: 'string' }, example: '100-200', description: 'Faixa de preço (inclusive)' }, { name: 'option[45]', in: 'query', schema: { type: 'string' }, example: 'GG,PP', description: 'Valores da opção de ID 45 (troque 45 pelo ID da opção)' }], responses: { 200: ok('Lista paginada', 'ProductList'), 400: err('Parâmetros inválidos') } } },
    '/v1/product': { post: { tags: ['Produtos'], summary: 'Cria produto (imagens em base64)', security: secured, requestBody: body('ProductInput'), responses: { 201: ok('Criado', 'Product'), 400: err('Dados inválidos ou token ausente'), 401: err('Token inválido') } } },
    '/v1/product/{id}': {
      get: { tags: ['Produtos'], summary: 'Obtém produto pelo ID', parameters: [idParam], responses: { 200: ok('Produto', 'Product'), 404: err('Não encontrado') } },
      put: { tags: ['Produtos'], summary: 'Atualiza produto (campos opcionais; images/options aceitam criar, atualizar e remover)', security: secured, parameters: [idParam], requestBody: body('ProductInput'), responses: { 204: { description: 'Atualizado' }, 400: err('Dados inválidos ou token ausente'), 401: err('Token inválido'), 404: err('Não encontrado') } },
      delete: { tags: ['Produtos'], summary: 'Remove produto', security: secured, parameters: [idParam], responses: { 204: { description: 'Removido' }, 400: err('Token ausente'), 401: err('Token inválido'), 404: err('Não encontrado') } },
    },
    '/health': { get: { tags: ['Utilitários'], summary: 'Verifica se a API está no ar', responses: { 200: { description: '{"status":"ok"}' } } } },
  },
};
