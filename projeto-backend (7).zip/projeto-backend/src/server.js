// Ponto de entrada: conecta no banco e coloca a API para escutar na porta configurada.
require('dotenv').config(); // carrega o .env antes de qualquer outra coisa
const app = require('./app'); // aplicação Express
const { sequelize } = require('./models'); // conexão com o banco

const PORT = Number(process.env.PORT) || 3000; // porta da API

async function start() {
  try {
    await sequelize.authenticate(); // testa a conexão antes de aceitar requisições
    app.listen(PORT, () => console.log(`API rodando na porta ${PORT} (documentação em /api-docs)`));
  } catch (err) {
    console.error('Não foi possível conectar ao banco:', err.message); // dica: confira o .env e se o MySQL está ligado
    process.exit(1); // encerra com código de erro
  }
}

start();
