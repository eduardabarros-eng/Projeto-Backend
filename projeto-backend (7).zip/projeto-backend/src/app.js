// Monta a aplicação Express (middlewares, rotas, erros) SEM iniciar o servidor — assim os testes importam o app direto.
const express = require('express'); // framework web
const qs = require('qs'); // interpreta query strings aninhadas, como option[45]=GG,PP
const swaggerUi = require('swagger-ui-express'); // página interativa de documentação
const swaggerSpec = require('./docs/swagger'); // especificação OpenAPI
const { uploadDir } = require('./config/upload'); // pasta das imagens
const userRoutes = require('./routes/userRoutes');
const categoryRoutes = require('./routes/categoryRoutes');
const productRoutes = require('./routes/productRoutes');
const errorHandler = require('./middleware/errorHandler');
const { requestContext } = require('./utils/requestContext'); // guarda o endereço público da requisição
const AppError = require('./utils/AppError');

const app = express(); // cria a aplicação

// Express 5 usa parser "simple" por padrão; trocamos pelo qs para entender option[ID]=valor.
// parseArrays:false evita que option[3]=GG vire uma lista (ids pequenos) em vez de objeto {"3":"GG"}
app.set('query parser', (str) => qs.parse(str, { parseArrays: false }));

app.use(requestContext); // memoriza o endereço de acesso (para montar URLs de imagem em qualquer máquina)
app.use(express.json({ limit: '10mb' })); // lê JSON do corpo; 10mb comporta imagens em base64

app.get('/health', (req, res) => res.json({ status: 'ok' })); // verificação de saúde
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec)); // Swagger UI
app.use('/media', express.static(uploadDir())); // serve as imagens enviadas

app.use('/v1/user', userRoutes); // rotas de usuários
app.use('/v1/category', categoryRoutes); // rotas de categorias
app.use('/v1/product', productRoutes); // rotas de produtos

// Qualquer rota não mapeada cai aqui e vira 404
app.use((req, res, next) => next(AppError.notFound('Rota não encontrada.')));
app.use(errorHandler); // sempre por último: formata todos os erros

module.exports = app;
