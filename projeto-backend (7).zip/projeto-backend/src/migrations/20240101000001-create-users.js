// Migration: cria (up) ou remove (down) a tabela "users".
'use strict';

module.exports = {
  // up: executado por "npm run db:migrate"
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('users', {
      id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true, allowNull: false }, // PK
      firstname: { type: Sequelize.STRING, allowNull: false }, // primeiro nome
      surname: { type: Sequelize.STRING, allowNull: false }, // sobrenome
      email: { type: Sequelize.STRING, allowNull: false, unique: true }, // e-mail único
      password: { type: Sequelize.STRING, allowNull: false }, // hash bcrypt
      created_at: { type: Sequelize.DATE, allowNull: false }, // data de criação
      updated_at: { type: Sequelize.DATE, allowNull: false }, // data da última alteração
    });
  },
  // down: executado por "npm run db:migrate:undo"
  async down(queryInterface) {
    await queryInterface.dropTable('users');
  },
};
