// Migration: cria (up) ou remove (down) a tabela "product_images".
'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('product_images', {
      id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true, allowNull: false },
      product_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: { model: 'products', key: 'id' }, // chave estrangeira para products.id
        onDelete: 'CASCADE', // apagar o produto apaga suas imagens
        onUpdate: 'CASCADE',
      },
      enabled: { type: Sequelize.BOOLEAN, allowNull: false, defaultValue: false }, // habilitada?
      path: { type: Sequelize.STRING, allowNull: false }, // caminho relativo do arquivo
    });
    await queryInterface.addIndex('product_images', ['product_id'], { name: 'idx_product_images_product' });
  },
  async down(queryInterface) {
    await queryInterface.dropTable('product_images');
  },
};
