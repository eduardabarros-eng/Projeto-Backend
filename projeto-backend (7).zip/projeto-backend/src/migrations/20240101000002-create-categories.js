// Migration: cria (up) ou remove (down) a tabela "categories".
'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('categories', {
      id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true, allowNull: false },
      name: { type: Sequelize.STRING, allowNull: false }, // nome da categoria
      slug: { type: Sequelize.STRING, allowNull: false }, // slug da categoria
      use_in_menu: { type: Sequelize.BOOLEAN, allowNull: false, defaultValue: false }, // aparece no menu?
      created_at: { type: Sequelize.DATE, allowNull: false },
      updated_at: { type: Sequelize.DATE, allowNull: false },
    });
  },
  async down(queryInterface) {
    await queryInterface.dropTable('categories');
  },
};
