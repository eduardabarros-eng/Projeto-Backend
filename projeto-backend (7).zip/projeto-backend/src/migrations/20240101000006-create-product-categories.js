// Migration: cria (up) ou remove (down) a tabela de ligação "product_categories".
'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('product_categories', {
      product_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        primaryKey: true, // parte da chave primária composta
        references: { model: 'products', key: 'id' },
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE',
      },
      category_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        primaryKey: true, // parte da chave primária composta (impede duplicar o par)
        references: { model: 'categories', key: 'id' },
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE',
      },
    });
    // Índice em category_id: a PK composta já cobre buscas por product_id
    await queryInterface.addIndex('product_categories', ['category_id'], { name: 'idx_product_categories_category' });
  },
  async down(queryInterface) {
    await queryInterface.dropTable('product_categories');
  },
};
