// Migration: cria (up) ou remove (down) a tabela "products", com índices para acelerar buscas.
'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('products', {
      id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true, allowNull: false },
      enabled: { type: Sequelize.BOOLEAN, allowNull: false, defaultValue: false }, // habilitado?
      name: { type: Sequelize.STRING, allowNull: false }, // nome
      slug: { type: Sequelize.STRING, allowNull: false }, // slug
      use_in_menu: { type: Sequelize.BOOLEAN, allowNull: false, defaultValue: false }, // aparece no menu?
      stock: { type: Sequelize.INTEGER, allowNull: false, defaultValue: 0 }, // estoque
      description: { type: Sequelize.STRING(1000), allowNull: true }, // descrição opcional
      price: { type: Sequelize.FLOAT, allowNull: false }, // preço
      price_with_discount: { type: Sequelize.FLOAT, allowNull: false }, // preço com desconto
      created_at: { type: Sequelize.DATE, allowNull: false },
      updated_at: { type: Sequelize.DATE, allowNull: false },
    });
    // Índices nas colunas mais usadas nos filtros da busca
    await queryInterface.addIndex('products', ['name'], { name: 'idx_products_name' });
    await queryInterface.addIndex('products', ['price'], { name: 'idx_products_price' });
  },
  async down(queryInterface) {
    await queryInterface.dropTable('products');
  },
};
