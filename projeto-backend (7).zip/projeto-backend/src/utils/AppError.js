// Erro "esperado" da aplicação, carregando o status HTTP que deve ser devolvido ao cliente.
class AppError extends Error {
  constructor(status, message) {
    super(message); // guarda a mensagem no Error padrão
    this.status = status; // status HTTP (400, 401, 404...)
    this.isAppError = true; // marca para o errorHandler saber que é um erro tratado
  }
}

// Atalhos para criar os erros mais comuns
AppError.badRequest = (msg) => new AppError(400, msg); // dados inválidos
AppError.unauthorized = (msg) => new AppError(401, msg); // token inválido
AppError.notFound = (msg = 'Recurso não encontrado.') => new AppError(404, msg); // não existe

module.exports = AppError;
