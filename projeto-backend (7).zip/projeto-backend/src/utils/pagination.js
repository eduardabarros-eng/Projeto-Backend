// Utilitários de paginação (limit/page) e seleção de campos (fields) das buscas.
const AppError = require('./AppError'); // erro com status HTTP

// Lê limit e page da query string. Padrões: limit=12, page=1. limit=-1 devolve tudo.
function parsePagination(query) {
  let limit = 12; // padrão do escopo
  let page = 1; // padrão do escopo
  if (query.limit !== undefined) {
    if (!/^-?\d+$/.test(String(query.limit))) throw AppError.badRequest('O parâmetro "limit" deve ser um número inteiro.');
    limit = Number(query.limit);
    if (limit === 0 || limit < -1) throw AppError.badRequest('O parâmetro "limit" deve ser -1 (todos) ou um inteiro maior que zero.');
  }
  if (query.page !== undefined) {
    if (!/^\d+$/.test(String(query.page)) || Number(query.page) < 1) throw AppError.badRequest('O parâmetro "page" deve ser um inteiro maior ou igual a 1.');
    page = Number(query.page);
  }
  const all = limit === -1; // com -1 a página não tem efeito
  return { limit, page: all ? 1 : page, all, offset: all ? 0 : (page - 1) * limit };
}

// Lê "fields=a,b,c" e confere se todos existem em "allowed"; devolve a lista ou null (= todos)
function parseFields(raw, allowed) {
  if (raw === undefined) return null;
  if (typeof raw !== 'string' || raw.trim() === '') throw AppError.badRequest('O parâmetro "fields" deve listar campos separados por vírgula.');
  const fields = raw.split(',').map((f) => f.trim()).filter(Boolean);
  const invalid = fields.filter((f) => !allowed.includes(f));
  if (invalid.length) throw AppError.badRequest(`Campos inválidos em "fields": ${invalid.join(', ')}.`);
  return fields;
}

// Mantém em "obj" apenas as chaves pedidas em "fields" (null = devolve o objeto inteiro)
function pickFields(obj, fields) {
  if (!fields) return obj;
  return Object.fromEntries(fields.map((f) => [f, obj[f]]));
}

module.exports = { parsePagination, parseFields, pickFields };
