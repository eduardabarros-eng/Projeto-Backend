// Funções reutilizáveis de validação. Todas lançam AppError 400 quando o valor é inválido.
const AppError = require('./AppError'); // erro com status HTTP

const has = (obj, key) => obj[key] !== undefined; // true quando o campo foi enviado

// Garante que o corpo da requisição seja um objeto JSON (e não lista, texto ou vazio)
function ensureObject(body) {
  if (body === undefined || body === null) return {}; // corpo ausente vira objeto vazio
  if (typeof body !== 'object' || Array.isArray(body)) throw AppError.badRequest('O corpo da requisição deve ser um objeto JSON.');
  return body;
}

// Texto obrigatório e não vazio; devolve o texto sem espaços nas pontas
function requireString(value, field, max = 255) {
  if (typeof value !== 'string' || value.trim() === '') throw AppError.badRequest(`O campo "${field}" é obrigatório e deve ser um texto.`);
  if (value.trim().length > max) throw AppError.badRequest(`O campo "${field}" deve ter no máximo ${max} caracteres.`);
  return value.trim();
}

// Booleano estrito (true/false); aceita também as strings "true"/"false"
function toBoolean(value, field) {
  if (typeof value === 'boolean') return value;
  if (value === 'true') return true;
  if (value === 'false') return false;
  throw AppError.badRequest(`O campo "${field}" deve ser true ou false.`);
}

// Número finito maior ou igual a zero (usado em preços)
function toNonNegativeNumber(value, field) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) throw AppError.badRequest(`O campo "${field}" deve ser um número maior ou igual a zero.`);
  return value;
}

// Inteiro maior ou igual a zero (usado em estoque)
function toNonNegativeInt(value, field) {
  if (!Number.isInteger(value) || value < 0) throw AppError.badRequest(`O campo "${field}" deve ser um inteiro maior ou igual a zero.`);
  return value;
}

// Converte um id vindo da URL em número; devolve null se não for um inteiro positivo
function parseId(value) {
  return /^\d+$/.test(String(value)) && Number(value) > 0 ? Number(value) : null;
}

// Valida e normaliza um e-mail (minúsculo, formato simples nome@dominio.ext)
function toEmail(value, field = 'email') {
  const email = requireString(value, field);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw AppError.badRequest(`O campo "${field}" deve ser um e-mail válido.`);
  return email.toLowerCase();
}

// Lista de ids inteiros positivos, sem repetição (usada em category_ids)
function toIdList(value, field) {
  if (!Array.isArray(value)) throw AppError.badRequest(`O campo "${field}" deve ser uma lista de ids.`);
  const ids = value.map((v) => {
    if (!Number.isInteger(v) || v <= 0) throw AppError.badRequest(`O campo "${field}" deve conter apenas ids inteiros positivos.`);
    return v;
  });
  return [...new Set(ids)];
}

module.exports = { has, ensureObject, requireString, toBoolean, toNonNegativeNumber, toNonNegativeInt, parseId, toEmail, toIdList };
