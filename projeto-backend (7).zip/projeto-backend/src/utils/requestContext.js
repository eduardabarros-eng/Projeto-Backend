// Guarda, durante cada requisição, o endereço público pelo qual o cliente acessou a API.
// Assim os services (que não enxergam o "req") conseguem montar URLs de imagem corretas em qualquer computador.
const { AsyncLocalStorage } = require('async_hooks'); // armazenamento que "acompanha" a requisição

const storage = new AsyncLocalStorage();

// Middleware: registra "protocolo://host" da requisição atual e segue o fluxo
function requestContext(req, res, next) {
  const baseUrl = `${req.protocol}://${req.get('host')}`; // ex.: http://192.168.0.10:3000 ou https://minha-api.com
  storage.run({ baseUrl }, next); // tudo que rodar a partir daqui enxerga esse valor
}

// Devolve o endereço da requisição atual (ou undefined fora de uma requisição)
const currentBaseUrl = () => (storage.getStore() || {}).baseUrl;

module.exports = { requestContext, currentBaseUrl };
