# Sobre o projeto

## Descrição curta (campo "About" do GitHub)

> API REST de loja virtual com Node.js, Express, Sequelize, MySQL e JWT: usuários, categorias e produtos (com imagens e opções), documentada com Swagger e testada com Jest.

**Tópicos sugeridos:** `nodejs` `express` `sequelize` `mysql` `jwt` `swagger` `jest` `rest-api`

---

## O que é

Uma API que serve de "cérebro" para uma loja online. Um site ou aplicativo (o front-end) conversa com ela por requisições HTTP para:

- **cadastrar usuários** e fazer **login**;
- **organizar a loja em categorias** (Calçados, Ofertas...);
- **cadastrar produtos** com preço, desconto, estoque, fotos, opções (tamanho, cor) e várias categorias;
- **buscar produtos** com filtros e paginação.

O projeto foi desenvolvido a partir do escopo do curso: <https://github.com/digitalcollegebr/projeto-backend>.

## Como funciona

Cada requisição passa por camadas, e cada camada tem uma única função:

```
requisição → rota → (auth) → controller → service → model → MySQL
```

| Camada | Papel |
|---|---|
| **Rota** | Decide qual código atende cada URL e se ela exige login. |
| **Auth** | Confere o token JWT nas rotas de escrita (POST, PUT, DELETE). |
| **Controller** | Recebe a requisição, chama o service e devolve o status HTTP certo. |
| **Service** | Concentra as regras de negócio e as validações. |
| **Model** | Descreve as tabelas e conversa com o banco (Sequelize). |
| **errorHandler** | Único ponto que transforma erros em respostas `{ "message": ... }`. |

### Autenticação

1. O usuário se cadastra (`POST /v1/user`); a senha é guardada apenas como hash **bcrypt**.
2. Faz login (`POST /v1/user/token`) e recebe um **token JWT**.
3. Envia o token em `Authorization: Bearer <token>` nas rotas protegidas.
4. Sem o cabeçalho a API responde **400**; com token falso ou expirado, **401**.

As rotas de leitura (GET) são públicas.

### Produtos, imagens e opções

- As imagens chegam em **base64**, são gravadas em `uploads/product-<id>/` com nome aleatório e servidas em `/media`. No banco fica só o caminho.
- No `PUT`, cada item de `images` e `options` funciona assim: **sem `id` cria**, `{id, deleted:true}` **remove**, `{id, ...campos}` **atualiza**.
- Criar, atualizar e apagar um produto é **tudo ou nada** (transação): se algo falhar, nada é salvo e os arquivos já gravados são apagados.

### Busca de produtos

`GET /v1/product/search` aceita `limit`, `page`, `fields`, `match`, `category_ids`, `price-range` e `option[ID]`, todos combináveis. A resposta traz `data`, `total`, `limit` e `page`.

## Como foi pensado

- **Camadas separadas (inspiradas em MVC e SOLID):** facilita entender, testar e mudar uma parte sem quebrar as outras.
- **Banco versionado com migrations:** qualquer pessoa recria o banco igual com `npm run db:migrate`, e cada tabela tem `up` e `down`.
- **Integridade no próprio banco:** chaves estrangeiras com `ON DELETE CASCADE` e chave primária composta na tabela de ligação produto × categoria.
- **Consultas eficientes:** a busca faz uma consulta só de ids (com total para paginar) e carrega imagens, opções e categorias em lote, sem o problema de N+1 consultas.
- **Validação centralizada:** os mesmos validadores servem a todas as rotas e devolvem mensagens claras.
- **Segredos fora do código:** tudo vem do `.env`; o repositório só traz o `.env.example`.
- **Testes isolados:** usam SQLite em memória e uma pasta temporária para imagens, então não tocam nos seus dados.
- **Documentação viva:** Swagger em `/api-docs`, onde dá para testar a API pelo navegador.

## Funciona em qualquer computador

Nada no código está preso a `localhost`:

- **Links das imagens:** são montados com o endereço usado na requisição (IP ou domínio), ou com `BASE_URL` do `.env`, se definido.
- **Exemplos do README:** usam a variável `API_URL`; basta trocá-la uma vez pelo endereço da sua máquina ou servidor.
- **Banco de dados:** host, porta, usuário, senha e nome vêm do `.env` (`DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASS`, `DB_NAME`).
- **Docker:** `docker compose up --build` sobe MySQL + API (com migrations automáticas) igual em Windows, macOS e Linux, sem instalar Node nem MySQL.

## Como rodar (resumo)

Com Docker (qualquer máquina):

```bash
docker compose up --build   # http://localhost:3000  ·  docs em /api-docs
```

Sem Docker:

```bash
npm install
cp .env.example .env     # preencha DB_USER, DB_PASS, DB_NAME e JWT_SECRET
npm run db:create
npm run db:migrate
npm run dev              # http://localhost:3000  ·  docs em /api-docs
npm test
```

Detalhes completos no [README](../README.md) e o papel de cada arquivo em [GUIA-DOS-ARQUIVOS.md](GUIA-DOS-ARQUIVOS.md).

## Limitações e próximos passos

- Qualquer usuário autenticado pode alterar categorias, produtos e contas, porque o escopo não define "donos" dos registros.
- Valores de opções não podem conter vírgula, pois ficam salvos em texto separado por vírgula.
- Ideias para evoluir: permissões por perfil (admin/cliente), carrinho e pedidos, upload em nuvem (S3), rate limiting e CI com GitHub Actions.
