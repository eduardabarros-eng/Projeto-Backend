# Guia dos arquivos — para que serve cada um e como usar

Este guia explica **cada arquivo** do projeto. No código, cada linha também tem um comentário em português.

## Como uma requisição percorre o projeto

```
cliente → app.js → routes/ → middleware/auth.js (se rota protegida) → controllers/ → services/ → models/ → MySQL
                                                                          erros → middleware/errorHandler.js → resposta JSON
```

## Raiz do projeto

| Arquivo | Para que serve |
|---|---|
| `package.json` | Lista dependências e scripts (`npm run dev`, `npm test`, `npm run db:migrate`...). |
| `.env.example` | Modelo das configurações. Copie para `.env` e preencha (o `.env` real nunca vai para o Git). |
| `.gitignore` | Diz ao Git o que **não** versionar: `node_modules`, `.env`, imagens enviadas. |
| `.sequelizerc` | Diz ao `sequelize-cli` onde ficam a configuração do banco e as migrations. |
| `README.md` | Apresentação, instalação, uso e referência da API. |
| `uploads/` | Onde as imagens dos produtos são gravadas (`.gitkeep` só mantém a pasta no Git). |

## `src/config/` — configurações
| Arquivo | Para que serve |
|---|---|
| `database.js` | Credenciais do MySQL (lidas do `.env`) por ambiente; nos testes usa SQLite em memória. |
| `jwt.js` | Segredo e validade dos tokens JWT. |
| `upload.js` | Pasta das imagens, URL pública e tipos de imagem aceitos. |

## `src/models/` — tabelas como código (Sequelize)
| Arquivo | Tabela | Observação |
|---|---|---|
| `User.js` | `users` | Senha guardada como hash bcrypt. |
| `Category.js` | `categories` | `use_in_menu` padrão `false`. |
| `Product.js` | `products` | Preço, desconto, estoque, etc. |
| `ProductImage.js` | `product_images` | Guarda só o caminho do arquivo. |
| `ProductOption.js` | `product_options` | Opções como tamanho/cor; `values` separados por vírgula. |
| `ProductCategory.js` | `product_categories` | Liga produtos a categorias (N-N). |
| `index.js` | — | Cria a conexão, registra os models e define os relacionamentos (com CASCADE). |

## `src/migrations/` — versionamento do banco
Uma migration por tabela, na ordem de criação. `up` cria a tabela; `down` desfaz.
Uso: `npm run db:migrate` (aplica) · `npm run db:migrate:undo` (desfaz a última).

## `src/routes/` — mapa de URLs
`userRoutes.js`, `categoryRoutes.js` e `productRoutes.js` ligam cada **método + URL** a um controller e dizem quais rotas passam pelo `auth`.
Detalhe importante: `/search` e `/token` são declaradas **antes** de `/:id`, senão o Express trataria "search" como um id.

## `src/controllers/` — porta de entrada HTTP
Recebem `req`/`res`, chamam o service e escolhem o status de sucesso (200, 201 ou 204). Não têm regra de negócio.

## `src/services/` — regras de negócio
| Arquivo | Responsabilidade |
|---|---|
| `userService.js` | Cadastro (valida, checa e-mail duplicado, gera hash), login (gera JWT), atualizar e remover. |
| `categoryService.js` | CRUD e busca paginada com `fields` e `use_in_menu`. |
| `productService.js` | Validação do produto, busca com filtros, criar/atualizar/remover **em transação**, imagens e opções. |
| `imageStorage.js` | Decodifica base64, grava/apaga arquivos e monta a URL pública. |

## `src/middleware/`
| Arquivo | Para que serve |
|---|---|
| `auth.js` | Exige `Authorization: Bearer <jwt>`. Sem cabeçalho → 400; token inválido/expirado → 401. |
| `errorHandler.js` | Único lugar que transforma erros em resposta JSON `{ "message": ... }`. |

## `src/utils/`
| Arquivo | Para que serve |
|---|---|
| `AppError.js` | Erro com status HTTP (`badRequest`, `unauthorized`, `notFound`). |
| `validators.js` | Funções de validação reutilizáveis (texto, booleano, e-mail, ids...). |
| `pagination.js` | Lê `limit`/`page`/`fields` da URL e valida. |

## `src/docs/swagger.js`
Especificação OpenAPI exibida em **`/api-docs`**. Clique em **Authorize** e cole o token para testar rotas protegidas.

## `src/app.js` e `src/server.js`
- `app.js` monta o Express (JSON, rotas, Swagger, `/media`, erros) **sem** ligar o servidor — por isso os testes conseguem importá-lo.
- `server.js` testa a conexão com o banco e começa a escutar na porta.

## `tests/`
| Arquivo | O que testa |
|---|---|
| `setup.js` | Prepara o ambiente de teste (SQLite, segredo, pasta temporária de imagens). |
| `helpers.js` | Funções auxiliares (login rápido, imagem PNG de exemplo). |
| `user.test.js` | Cadastro, login, JWT (400/401), GET/PUT/DELETE. |
| `category.test.js` | CRUD, paginação, `fields`, `use_in_menu`, erros. |
| `product.test.js` | CRUD, imagens no disco, opções, filtros combinados, transações, CASCADE. |

Rodar: `npm test`.
