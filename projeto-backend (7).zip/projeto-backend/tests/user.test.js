// Testes de usuários e autenticação JWT (Seções 02 e 05).
const { request, app, sequelize, resetDb } = require('./helpers');

const valid = { firstname: 'Maria', surname: 'Silva', email: 'maria@mail.com', password: '123@123', confirmPassword: '123@123' };

beforeAll(resetDb); // tabelas limpas
afterAll(() => sequelize.close()); // fecha a conexão

describe('Usuários e JWT', () => {
  let id, auth;

  test('POST /v1/user cadastra e não devolve a senha (201)', async () => {
    const res = await request(app).post('/v1/user').send(valid);
    expect(res.status).toBe(201);
    expect(res.body.password).toBeUndefined();
    id = res.body.id;
  });

  test('POST /v1/user com senhas diferentes → 400', async () => {
    const res = await request(app).post('/v1/user').send({ ...valid, email: 'x@mail.com', confirmPassword: 'outra' });
    expect(res.status).toBe(400);
  });

  test('POST /v1/user com e-mail repetido → 400', async () => {
    expect((await request(app).post('/v1/user').send(valid)).status).toBe(400);
  });

  test('POST /v1/user/token com senha errada → 400', async () => {
    expect((await request(app).post('/v1/user/token').send({ email: valid.email, password: 'errada' })).status).toBe(400);
  });

  test('POST /v1/user/token devolve o token (200)', async () => {
    const res = await request(app).post('/v1/user/token').send({ email: valid.email, password: valid.password });
    expect(res.status).toBe(200);
    expect(typeof res.body.token).toBe('string');
    auth = { Authorization: `Bearer ${res.body.token}` };
  });

  test('GET /v1/user/:id → 200 e 404', async () => {
    const ok = await request(app).get(`/v1/user/${id}`);
    expect(ok.status).toBe(200);
    expect(ok.body).toEqual({ id, firstname: 'Maria', surname: 'Silva', email: 'maria@mail.com' });
    expect((await request(app).get('/v1/user/9999')).status).toBe(404);
  });

  test('PUT sem cabeçalho → 400; token falso → 401', async () => {
    expect((await request(app).put(`/v1/user/${id}`).send({ firstname: 'Ana' })).status).toBe(400);
    expect((await request(app).put(`/v1/user/${id}`).set('Authorization', 'Bearer falso').send({ firstname: 'Ana' })).status).toBe(401);
  });

  test('PUT atualiza (204) e 404 para id inexistente', async () => {
    expect((await request(app).put(`/v1/user/${id}`).set(auth).send({ firstname: 'Ana' })).status).toBe(204);
    expect((await request(app).get(`/v1/user/${id}`)).body.firstname).toBe('Ana');
    expect((await request(app).put('/v1/user/9999').set(auth).send({ firstname: 'Ana' })).status).toBe(404);
  });

  test('PUT com e-mail inválido → 400', async () => {
    expect((await request(app).put(`/v1/user/${id}`).set(auth).send({ email: 'invalido' })).status).toBe(400);
  });

  test('DELETE remove (204) e depois 404', async () => {
    expect((await request(app).delete(`/v1/user/${id}`).set(auth).send()).status).toBe(204);
    expect((await request(app).get(`/v1/user/${id}`)).status).toBe(404);
  });
});
