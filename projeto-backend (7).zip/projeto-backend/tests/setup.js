// Executado pelo Jest ANTES de cada arquivo de teste: prepara variáveis de ambiente isoladas.
const os = require('os');
const fs = require('fs');
const path = require('path');

process.env.NODE_ENV = 'test'; // usa SQLite em memória (ver src/config/database.js)
process.env.JWT_SECRET = 'segredo-de-teste'; // segredo fixo para os testes
delete process.env.BASE_URL; // sem BASE_URL: a URL das imagens deve vir do endereço da própria requisição
process.env.UPLOAD_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'loja-uploads-')); // pasta temporária (caminho absoluto)
