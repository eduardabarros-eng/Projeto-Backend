// Testes do CRUD de produtos, imagens, opções, filtros e transações (Seção 04).
const fs = require('fs');
const path = require('path');
const { request, app, sequelize, PNG, resetDb, login } = require('./helpers');

let auth;
let cat1;
let cat2;

// Payload base de um produto válido
const base = (extra = {}) => ({ enabled: true, name: 'Tênis Runner', slug: 'tenis-runner', stock: 10, description: 'Tênis leve', price: 119.9, price_with_discount: 99.9, ...extra });

beforeAll(async () => {
  await resetDb();
  auth = await login();
  cat1 = (await request(app).post('/v1/category').set(auth).send({ name: 'Shoes', slug: 'shoes' })).body.id;
  cat2 = (await request(app).post('/v1/category').set(auth).send({ name: 'Offers', slug: 'offers' })).body.id;
});
afterAll(() => sequelize.close());

describe('Produtos', () => {
  let product;

  test('POST sem token → 400; token falso → 401', async () => {
    expect((await request(app).post('/v1/product').send(base())).status).toBe(400);
    expect((await request(app).post('/v1/product').set('Authorization', 'Bearer x').send(base())).status).toBe(401);
  });

  test('POST valida dados → 400 (campos, categoria inexistente, imagem inválida)', async () => {
    expect((await request(app).post('/v1/product').set(auth).send({ name: 'x' })).status).toBe(400);
    expect((await request(app).post('/v1/product').set(auth).send(base({ category_ids: [999] }))).status).toBe(400);
    expect((await request(app).post('/v1/product').set(auth).send(base({ images: [{ type: 'text/plain', content: PNG }] }))).status).toBe(400);
    expect((await request(app).post('/v1/product').set(auth).send(base({ options: [{ title: 'T', values: [] }] }))).status).toBe(400);
  });

  test('POST cria com categorias, imagem e opções (201) e grava o arquivo', async () => {
    const res = await request(app).post('/v1/product').set(auth).send(base({
      category_ids: [cat1],
      images: [{ type: 'image/png', content: PNG }],
      options: [{ title: 'Tamanho', shape: 'square', radius: '4px', type: 'text', values: ['40', '41', '42'] }],
    }));
    expect(res.status).toBe(201);
    product = res.body;
    expect(product.category_ids).toEqual([cat1]);
    expect(product.images[0].content).toMatch(/^http:\/\/[^/]+\/media\/product-\d+\/.+\.png$/);
    expect(product.options[0]).toMatchObject({ title: 'Tamanho', radius: 4, values: ['40', '41', '42'] });
    const relative = product.images[0].content.split('/media/')[1];
    expect(fs.existsSync(path.join(process.env.UPLOAD_DIR, relative))).toBe(true); // arquivo realmente no disco
  });

  test('POST com erro no meio da transação não deixa produto nem arquivo órfão', async () => {
    const before = (await request(app).get('/v1/product/search?limit=-1')).body.total;
    const filesBefore = fs.readdirSync(process.env.UPLOAD_DIR, { recursive: true }).filter((f) => /\.png$/.test(f)).length;
    const res = await request(app).post('/v1/product').set(auth).send(base({ slug: 'falha', images: [{ type: 'image/png', content: PNG }], category_ids: [999] }));
    expect(res.status).toBe(400);
    expect((await request(app).get('/v1/product/search?limit=-1')).body.total).toBe(before); // nenhum produto criado
    const filesAfter = fs.readdirSync(process.env.UPLOAD_DIR, { recursive: true }).filter((f) => /\.png$/.test(f)).length;
    expect(filesAfter).toBe(filesBefore); // nenhum arquivo órfão ficou no disco
  });

  test('GET /:id → 200 e 404', async () => {
    expect((await request(app).get(`/v1/product/${product.id}`)).body.name).toBe('Tênis Runner');
    expect((await request(app).get('/v1/product/9999')).status).toBe(404);
  });

  test('GET /search: match, categoria, faixa de preço, option, fields e paginação', async () => {
    await request(app).post('/v1/product').set(auth).send(base({ name: 'Camisa', slug: 'camisa', description: 'Algodão', price: 50, price_with_discount: 40, category_ids: [cat2], options: [{ title: 'Tam', values: ['PP', 'GG'] }] }));
    const get = (q) => request(app).get(`/v1/product/search${q}`);
    expect((await get('?match=Tênis')).body.total).toBe(1);
    expect((await get('?match=algod')).body.total).toBe(1); // busca também na descrição
    expect((await get(`?category_ids=${cat1},${cat2}`)).body.total).toBe(2);
    expect((await get(`?category_ids=${cat2}`)).body.data[0].slug).toBe('camisa');
    expect((await get('?price-range=100-200')).body.data.map((p) => p.slug)).toEqual(['tenis-runner']);
    const optionId = (await get('?match=Camisa')).body.data[0].options[0].id;
    expect((await get(`?option[${optionId}]=GG,M`)).body.total).toBe(1);
    expect((await get(`?option[${optionId}]=XL`)).body.total).toBe(0);
    expect((await get(`?category_ids=${cat2}&price-range=100-200`)).body.total).toBe(0); // filtros combinados
    expect(Object.keys((await get('?fields=name,price&limit=1')).body.data[0])).toEqual(['name', 'price']);
    const page = await get('?limit=1&page=2');
    expect(page.body).toMatchObject({ total: 2, limit: 1, page: 2 });
    expect(page.body.data).toHaveLength(1);
  });

  test('GET /search com parâmetros inválidos → 400', async () => {
    expect((await request(app).get('/v1/product/search?price-range=abc')).status).toBe(400);
    expect((await request(app).get('/v1/product/search?category_ids=a,b')).status).toBe(400);
    expect((await request(app).get('/v1/product/search?page=0')).status).toBe(400);
  });

  test('PUT atualiza campos, categorias, imagens e opções (204)', async () => {
    const oldPath = path.join(process.env.UPLOAD_DIR, product.images[0].content.split('/media/')[1]);
    const res = await request(app).put(`/v1/product/${product.id}`).set(auth).send({
      name: 'Tênis Atualizado', price_with_discount: 0, category_ids: [cat2],
      images: [{ type: 'image/png', content: PNG }, { id: product.images[0].id, deleted: true }],
      options: [{ id: product.options[0].id, radius: '10px', value: ['42/43'] }, { title: 'Cor', type: 'color', shape: 'circle', values: ['#000'] }],
    });
    expect(res.status).toBe(204);
    const now = (await request(app).get(`/v1/product/${product.id}`)).body;
    expect(now).toMatchObject({ name: 'Tênis Atualizado', price_with_discount: 0, category_ids: [cat2] });
    expect(now.images).toHaveLength(1); // a antiga saiu, uma nova entrou
    expect(fs.existsSync(oldPath)).toBe(false); // arquivo antigo removido do disco
    expect(now.options.find((o) => o.id === product.options[0].id)).toMatchObject({ radius: 10, values: ['42/43'] });
    expect(now.options).toHaveLength(2);
  });

  test('PUT: troca a imagem por base64 novo e mantém quando content é URL', async () => {
    const current = (await request(app).get(`/v1/product/${product.id}`)).body.images[0];
    await request(app).put(`/v1/product/${product.id}`).set(auth).send({ images: [{ id: current.id, content: current.content }] });
    expect((await request(app).get(`/v1/product/${product.id}`)).body.images[0].content).toBe(current.content);
    await request(app).put(`/v1/product/${product.id}`).set(auth).send({ images: [{ id: current.id, content: PNG }] });
    expect((await request(app).get(`/v1/product/${product.id}`)).body.images[0].content).not.toBe(current.content);
  });

  test('PUT: 400 para dados inválidos, 401/400 sem token, 404 inexistente', async () => {
    expect((await request(app).put(`/v1/product/${product.id}`).set(auth).send({ price: -1 })).status).toBe(400);
    expect((await request(app).put(`/v1/product/${product.id}`).set(auth).send({ images: [{ id: 9999, deleted: true }] })).status).toBe(400);
    expect((await request(app).put(`/v1/product/${product.id}`).send({ name: 'x' })).status).toBe(400);
    expect((await request(app).put('/v1/product/9999').set(auth).send({ name: 'x' })).status).toBe(404);
  });

  test('DELETE remove produto, arquivos e ligações (204) e depois 404', async () => {
    const folder = path.join(process.env.UPLOAD_DIR, `product-${product.id}`);
    expect(fs.existsSync(folder)).toBe(true);
    expect((await request(app).delete(`/v1/product/${product.id}`).set(auth)).status).toBe(204);
    expect(fs.existsSync(folder)).toBe(false);
    expect((await request(app).get(`/v1/product/${product.id}`)).status).toBe(404);
    expect((await request(app).delete(`/v1/product/${product.id}`).set(auth)).status).toBe(404);
  });

  test('Apagar uma categoria remove a ligação, mas não o produto (CASCADE)', async () => {
    await request(app).delete(`/v1/category/${cat2}`).set(auth);
    const left = (await request(app).get('/v1/product/search?limit=-1')).body.data;
    expect(left.length).toBeGreaterThan(0);
    left.forEach((p) => expect(p.category_ids).not.toContain(cat2));
  });
});
