// Funções auxiliares compartilhadas pelos testes.
const request = require('supertest');
const app = require('../src/app');
const { sequelize } = require('../src/models');

// PNG de 1x1 pixel em base64, usado como imagem de teste
const PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';

// Recria todas as tabelas vazias (chamado em beforeAll de cada arquivo)
const resetDb = () => sequelize.sync({ force: true });

// Cadastra um usuário, faz login e devolve o cabeçalho Authorization pronto
async function login(email = 'maria@mail.com') {
  await request(app).post('/v1/user').send({ firstname: 'Maria', surname: 'Silva', email, password: '123@123', confirmPassword: '123@123' });
  const res = await request(app).post('/v1/user/token').send({ email, password: '123@123' });
  return { Authorization: `Bearer ${res.body.token}` };
}

module.exports = { request, app, sequelize, PNG, resetDb, login };
