// Testes do CRUD de categorias e da busca paginada (Seção 03).
const { request, app, sequelize, resetDb, login } = require('./helpers');

let auth;
beforeAll(async () => { await resetDb(); auth = await login(); });
afterAll(() => sequelize.close());

describe('Categorias', () => {
  test('POST sem token → 400; token falso → 401', async () => {
    expect((await request(app).post('/v1/category').send({ name: 'A', slug: 'a' })).status).toBe(400);
    expect((await request(app).post('/v1/category').set('Authorization', 'Bearer x').send({ name: 'A', slug: 'a' })).status).toBe(401);
  });

  test('POST valida os campos obrigatórios → 400', async () => {
    expect((await request(app).post('/v1/category').set(auth).send({ slug: 'a' })).status).toBe(400);
  });

  test('POST cria (201) com use_in_menu padrão false', async () => {
    const res = await request(app).post('/v1/category').set(auth).send({ name: 'Shoes', slug: 'shoes', use_in_menu: true });
    expect(res.status).toBe(201);
    const other = await request(app).post('/v1/category').set(auth).send({ name: 'Offers', slug: 'offers' });
    expect(other.body.use_in_menu).toBe(false);
  });

  test('GET /search: paginação, limit=-1, fields e use_in_menu', async () => {
    for (let i = 0; i < 4; i += 1) await request(app).post('/v1/category').set(auth).send({ name: `C${i}`, slug: `c${i}` });
    const page = await request(app).get('/v1/category/search?limit=2&page=2');
    expect(page.status).toBe(200);
    expect(page.body).toMatchObject({ total: 6, limit: 2, page: 2 });
    expect(page.body.data).toHaveLength(2);
    const all = await request(app).get('/v1/category/search?limit=-1');
    expect(all.body.data).toHaveLength(6);
    const fields = await request(app).get('/v1/category/search?fields=name,slug&limit=1');
    expect(Object.keys(fields.body.data[0])).toEqual(['name', 'slug']);
    const menu = await request(app).get('/v1/category/search?use_in_menu=true');
    expect(menu.body.total).toBe(1);
  });

  test('GET /search com parâmetros inválidos → 400', async () => {
    expect((await request(app).get('/v1/category/search?limit=abc')).status).toBe(400);
    expect((await request(app).get('/v1/category/search?fields=senha')).status).toBe(400);
  });

  test('GET /:id → 200 e 404', async () => {
    expect((await request(app).get('/v1/category/1')).body.slug).toBe('shoes');
    expect((await request(app).get('/v1/category/999')).status).toBe(404);
  });

  test('PUT atualiza (204), 400 e 404', async () => {
    expect((await request(app).put('/v1/category/1').set(auth).send({ name: 'Tênis', slug: 'tenis', use_in_menu: false })).status).toBe(204);
    expect((await request(app).get('/v1/category/1')).body.name).toBe('Tênis');
    expect((await request(app).put('/v1/category/1').set(auth).send({ name: '' })).status).toBe(400);
    expect((await request(app).put('/v1/category/999').set(auth).send({ name: 'x', slug: 'x' })).status).toBe(404);
  });

  test('DELETE remove (204) e depois 404', async () => {
    expect((await request(app).delete('/v1/category/1').set(auth)).status).toBe(204);
    expect((await request(app).delete('/v1/category/1').set(auth)).status).toBe(404);
  });
});
